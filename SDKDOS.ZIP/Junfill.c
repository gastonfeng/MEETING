#include <dos.h>
#include "junior2.h"
#include "extern.h"
#define  STACKSIZE      200

void select_segment(UINT y);
int  stack_buf[STACKSIZE];
int  stack_point;

void init_stack(void)
{
   int i;

   for (i=0; i<STACKSIZE; i++)
      stack_buf[i] = 0;
   stack_point = 0;
}

int  stack_push(UINT x, UINT y)
{
   if ( stack_point >= STACKSIZE )
      return(FALSE);
   stack_buf[stack_point++] = x;
   stack_buf[stack_point++] = y;
   return(TRUE);
}

int  stack_pop(UINT x, UINT y)
{
   if ( stack_point <= 0 )
      return(FALSE);
   stack_buf[--stack_point] = y;
   stack_buf[--stack_point] = x;
   return(TRUE);
}

void fill_one_line(UINT x, UINT y, UINT *xl, UINT *xr,
                   BYTE new_color, BYTE old_color)
{
   UINT	 start_line;
   UINT         tt;

   select_segment(y);
   start_line	 = (UINT) (y % 64);
   do {
      tt = video_memory[(start_line<<10) + x];
      x++;
   } while ( tt == old_color && x < 1023 )  ;
   x--;
   *xr = x;  //right-most of a line
   do {
      video_memory[(start_line<<10) + x] = new_color;
      x--;
      tt = video_memory[(start_line<<10) + x];
   } while ( tt == old_color && x > 0 );
   x++;
   *xl = x;   //left-most of a line
}

void find_right_most(UINT y, UINT xl, UINT xr, BYTE old_color)
{
   UINT	 start_line;
   int   x, xt, xp;

   if ( x < xl )  return;
   select_segment(y);
   start_line	 = (UINT) (y % 64);

   xt = xr;
   while ( video_memory[(start_line<<10) + xt] == old_color && xt < 1023 )
      xt++;
   if ( xt > xr ) {
      xt--;
      stack_push(xt, y);
   }
   do {
      xt--;
      while ( video_memory[(start_line<<10) + xt] != old_color && xt > 0 )
         xt--;
      if ( xt == 0 ) break;
      xp = xt;
      while ( video_memory[(start_line<<10) + xt] == old_color && xt > 0 )
         xt--;
      if ( xt == 0 ) break;
      if ( xt > xl ) {
         stack_push(xp, y);
      }
   } while ( xt <= xl );
   if ( xt == 0 )  stack_push(xp, y);
}

int  jun_flood_fill(UINT xs, UINT ys, BYTE new_color)
{
   int  x, y, xl, xr;
   UINT	 start_line;
   BYTE  old_color;

   select_segment(ys);
   start_line	 = (UINT) (ys % 64);

   old_color = video_memory[(start_line<<10) + xs];
   if ( old_color == new_color )
      return(TRUE);

   init_stack();
   x = xs;  y = ys;
   stack_push(x, y);
   while ( stack_point != 0 ) {
      stack_pop(x, y);
      fill_one_line(x, y, &xl, &xr, new_color, old_color);

      y = ys - 1;
      find_right_most(y, xl, xr, old_color);
      y = ys + 1;
      find_right_most(y, xl, xr, old_color);
  }
}

void select_segment(UINT y)
{
    static BYTE  prev_memory_segment=10;
    BYTE	 memory_segment;

   /* check the upper one line */
   memory_segment = y >> 6; // y / 64;
   // select the desired memory segment
   if ( memory_segment != prev_memory_segment ) // not previous memory segment
   {
      memory_seg_select(memory_segment);
      prev_memory_segment = memory_segment; // preserve this value
   }
}
