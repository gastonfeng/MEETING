// ****************************************************************************
// Project : junior.prj
// File    : junior.h
// Object  : header file of constant definition and function prototypes
// Author  : Ricky Hsu
// Date    : 820810
// Date    : 821204 Version 2.0 Tang
// ****************************************************************************
//#define  VGA_DISPLAY

typedef unsigned char		BYTE;
typedef unsigned int		UINT;
// 10/4 Tang added
typedef unsigned int		WORD;
typedef unsigned long		ULONG;
typedef struct tagRECT {
    int 	left;
    int 	top;
    int 	right;
    int 	bottom;
} RECT;

typedef struct tagPOINT {
    int 	x;
    int 	y;
} POINT;

#define min(a,b)	 (((a) < (b)) ? (a) : (b))
#define max(a,b)	 (((a) > (b)) ? (a) : (b))

#define  TRUE		 1
#define  FALSE		 0
#define  OPT_NUM	 8    // # of system options

#define  RED_PART	 0    // red color index of palette table
#define  GREEN_PART	 1    // green color index of palette table
#define  BLUE_PART	 2    // blue color index of palette table

#define  UNDERSCAN_MODE  0
#define  OVERSCAN_MODE	 1

#define  VIDEO_MEMORY_WIDTH	1024
#define  VIDEO_MEMORY_HEIGHT	512

#define  MEMORY_SIZE_16K        0x4000
#define  MEMORY_SIZE_8K         0x2000

#define  BANK_SIZE_64K          0
#define  BANK_SIZE_16K          1
#define  BANK_SIZE_8K           2

// ---------------------------------------------------------------------------
//			      Index of alphabet table
// ---------------------------------------------------------------------------
#define  CHAR_NUM	  95
#define  CHAR_WIDTH	  16
#define  CHAR_HEIGHT	  20
#define  LINE_MAX_CHAR	  (640 / CHAR_WIDTH)
#define  PAGE_MAX_LINE	  (480 / CHAR_HEIGHT)
#define  CH_A		  0
#define  CH_B		  1
#define  CH_C		  2
#define  CH_D		  3
#define  CH_E		  4
#define  CH_F		  5
#define  CH_G		  6
#define  CH_H		  7
#define  CH_I		  8
#define  CH_J		  9
#define  CH_K		 10
#define  CH_L		 11
#define  CH_M		 12
#define  CH_N		 13
#define  CH_O		 14
#define  CH_P		 15
#define  CH_Q		 16
#define  CH_R		 17
#define  CH_S		 18
#define  CH_T		 19
#define  CH_U		 20
#define  CH_V		 21
#define  CH_W		 22
#define  CH_X		 23
#define  CH_Y		 24
#define  CH_Z		 25

#define  CH_LA		( 0+26 )
#define  CH_LB		( 1+26 )
#define  CH_LC		( 2+26 )
#define  CH_LD		( 3+26 )
#define  CH_LE		( 4+26 )
#define  CH_LF		( 5+26 )
#define  CH_LG		( 6+26 )
#define  CH_LH		( 7+26 )
#define  CH_LI		( 8+26 )
#define  CH_LJ		( 9+26 )
#define  CH_LK		(10+26 )
#define  CH_LL		(11+26 )
#define  CH_LM		(12+26 )
#define  CH_LN		(13+26 )
#define  CH_LO		(14+26 )
#define  CH_LP		(15+26 )
#define  CH_LQ		(16+26 )
#define  CH_LR		(17+26 )
#define  CH_LS		(18+26 )
#define  CH_LT		(19+26 )
#define  CH_LU		(20+26 )
#define  CH_LV		(21+26 )
#define  CH_LW		(22+26 )
#define  CH_LX		(23+26 )
#define  CH_LY		(24+26 )
#define  CH_LZ		(25+26 )

#define  CH_BLANK	(26+26 )
#define  CH_SLASH	(41+26 )

#define  CH_0		(42+26 )
#define  CH_1		(43+26 )
#define  CH_2		(44+26 )
#define  CH_3		(45+26 )
#define  CH_4		(46+26 )
#define  CH_5		(47+26 )
#define  CH_6		(48+26 )
#define  CH_7		(49+26 )
#define  CH_8		(50+26 )
#define  CH_9		(51+26 )

#define  CH_COLON	(52+26 ) // :
#define  CH_QMARK	(57+26 ) // ?
#define  CH_SMALL_MOUSE (58+26 ) // @
#define  CH_BRACKET	(59+26 ) // [
#define  CH_UP_COMMA	(64+26 ) // {
#define  CH_LEFT_BRACE	(65+26 ) // {
#define  CH_FLY 	(68+26 ) // ~


// ---------------------------------------------------------------------------
//			 index of system options
// ---------------------------------------------------------------------------
#define  MEMORY_BASE		     '0'
#define  IO_BASE		     '1'
#define  CARD_ID		     '2'
#define  IRQ			     '3'
#define  COLOR_KEY		     '4'
#define  VERTICAL_SCAN_START	     '5'
#define  HORIZONTAL_SHIFT_PIXEL      '6'
#define  SCAN_MODE		     '7'

// ---------------------------------------------------------------------------
// 2X0(WRITE)		      control register
// ---------------------------------------------------------------------------
#define  MEMORY_SEGMENT0	      0  // Video memory segment 0
#define  MEMORY_SEGMENT1	      1  // Video memory segment 1
#define  MEMORY_SEGMENT2	      2  // Video memory segment 2
#define  MEMORY_SEGMENT3	      3  // Video memory segment 3
#define  MEMORY_SEGMENT4	      4  // Video memory segment 4
#define  MEMORY_SEGMENT5	      5  // Video memory segment 5
#define  MEMORY_SEGMENT6	      6  // Video memory segment 6
#define  MEMORY_SEGMENT7	      7  // Video memory segment 7
#define  MEMORY_READ_ENABLE	   0x00  // Video memory read enable
#define  MEMORY_READ_DISABLE	   0x08  // Video memory read disable
#define  MEMORY_WRITE_ENABLE	   0x00  // Video memory write enable
#define  MEMORY_WRITE_DISABLE	   0x10  // Video memory write disable
#define  EXTERNAL_VIDEO_ONLY	   0x00  // Video mode : external video only
#define  OVERLAY		   0x20  // Video mode : overlay
#define  VERT_SYNC_INT_ENABLE	   0x40  // vertical sync interrupt enable
#define  VERT_SYNC_INT_DISABLE	   0x00  // vertical sync interrupt disable
#define  FLASH_VIDEO_MEMORY	   0x80  // flash video memory enable

// ---------------------------------------------------------------------------
// 2X0(READ)		       status register
// ---------------------------------------------------------------------------
#define  EXTERNAL_VIDEO_EXIST	   0x01  // external video source exist
#define  NTSC			   0x00  // TV system type of Junior
#define  PAL			   0x02  // TV system type of Junior
#define  VERT_SYNC_INT_OCCUR	   0x04  // vertical sync interrupt occurs
#define  READ_BACK0		   0x00  // read back bit = 0
#define  READ_BACK1		   0x08  // read back bit = 1
#define  VERT_SYNC_PERIOD	   0x10  // raster scan is during vertical sync period

// ---------------------------------------------------------------------------
// 2X1(WRITE)		     corlor key register
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 2X2(WRITE)		      card ID register
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 2X3(WRITE)		      CRT select register
// ---------------------------------------------------------------------------
#define  VERT_SCROLL_REG_SEL	   0x00  // select vertical scroll register
#define  SCREEN_BORDER_REG_SEL     0x01  // select screen border register
#define  BLANK_TIMING_REG_SEL      0x02  // select blank timeing register
#define  HORZ_SHIFT_REG_SEL	   0x03  // select horizontal shift register

// ---------------------------------------------------------------------------
// Blank timing register(CRT_select_reg=02)
// ---------------------------------------------------------------------------
#define  MEMORY_READ_ENABLE_BT	   0x00  // Video memory read enable
#define  MEMORY_READ_DISABLE_BT    0x01  // Video memory read disable
#define  MEMORY_WRITE_ENABLE_BT	   0x00  // Video memory write enable
#define  MEMORY_WRITE_DISABLE_BT   0x02  // Video memory write disable
#define  SET_WHOLE_DISPLAY_COLOR   0xFB  // set whole display to a color
#define  RESET_WHOLE_DISPLAY_COLOR 0x04  // reset whole display to a color
#define  SET_HORZ_SCAN_START_MSB   0x08  // set MSB of horizontal shift reg.
#define  HORIZONTAL_WIDTH512       0x00  // select horizontal width 512 pixel
#define  HORIZONTAL_WIDTH640       0x10  // select horizontal width 640 pixels
#define  HORIZONTAL_WIDTH720       0x20  // select horizontal width 720 pixels
#define  VERTICAL_HEIGHT400        0x00  // select vertical height 400 pixels
#define  VERTICAL_HEIGHT480        0x40  // select vertical height 400 pixels
#define  VERTICAL_HEIGHT510        0x80  // select vertical height 400 pixels

// ---------------------------------------------------------------------------
// 2X8(WRITE)		     CRT data register
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 2X4(WRITE)		RAMDAC address write register
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 2X7(WRITE)		 RAMDAC address read register
// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
// 2X5(READ / WRITE)	     RAMDAC data register
// ---------------------------------------------------------------------------
// ***************************************************************************
//	       Define some usually used color's RAMDAC entries
// ***************************************************************************
#ifndef VGA_DISPLAY
  #define  JUN_BLACK		       16
  #define  JUN_WHITE		       31
  #define  JUN_BLUE 		       32
  #define  JUN_MAGENTA		       36 // default RAMDAC entry of color key
  #define  JUN_RED		       40
  #define  JUN_YELLOW		       44
  #define  JUN_GREEN		       48
  #define  JUN_CYAN 		       52
  #define  JUN_BROWN                   05
  #define  JUN_UNKNOWN                 0x6c
  #define  DEFAULT_COLOR	       JUN_WHITE
  #define  JUN_DEEPBLUE                104    //0x68
#endif

// ---------------------------------------------------------------------------
// 2X6(WRITE)		   RAMDAC input mask register
// ---------------------------------------------------------------------------


// 10/06 Tang added for Borland C
#define RSHIFT  ( BYTE ) 0x01
#define LSHIFT  ( BYTE ) 0x02
#define CTRL    ( BYTE ) 0x04
#define ALT     ( BYTE ) 0x08
#define YES	( BYTE ) 0x00
#define NO	( BYTE ) 0x01

#define MGA     ( BYTE ) 0x00
#define HERC    ( BYTE ) 0x01
#define CGA     ( BYTE ) 0x02
#define EGA     ( BYTE ) 0x03
#define VGA     ( BYTE ) 0x04
#define OTHERS  ( BYTE ) 0x05  /* lily add 7/2/91 */
#define LEFT    ( BYTE ) 0x4b
#define RIGHT   ( BYTE ) 0x4d
#define PGUP    ( BYTE ) 0x49
#define PGDN    ( BYTE ) 0x51
#define UP      ( BYTE ) 0x48
#define DOWN    ( BYTE ) 0x50
#define HOME    ( BYTE ) 0x47
#define END     ( BYTE ) 0x4f
#define ESC     ( BYTE ) 0x1b
#define RET     ( BYTE ) 0x0d
#define INS     ( BYTE ) 0x52
#define DEL     ( BYTE ) 0x53
#define TAB     ( BYTE ) 0x09
#define SPACE	( BYTE ) 0x20
#define q_KEY   ( BYTE ) 0x71
#define Q_KEY   ( BYTE ) 0x51
#define p_KEY   ( BYTE ) 0x70
#define P_KEY   ( BYTE ) 0x50
#define c_KEY   ( BYTE ) 0x63
#define C_KEY   ( BYTE ) 0x43
#define g_KEY   ( BYTE ) 0x67
#define G_KEY   ( BYTE ) 0x47



// ---------------------------------------------------------------------------
//		      function prototype declaractions
// ---------------------------------------------------------------------------
// ***************************************************************************
//				    junior.c
// ***************************************************************************
int   load_font_file(void),
      set_system_option(void),
      set_option(char  *option_string, UINT  option_index),
      init_io_register(void),
      set_junior_config(void),
      test_junior_exist(void),
      test_external_video_exist(void),
      test_graphics(void),
      test_video_memory(void),
      test_video_mode(void),
      test_ramdac(void),
      test_vertical_scroll(void),
      test_horz_shift(void),
      test_vert_sync_int(void),
      test_flash_memory(void);

UINT  hex_string_to_int(char *hex_str);

// ***************************************************************************
//				    junregs.c
// ***************************************************************************
// ===========================================================================
// 2X0(WRITE)		      control register functions
// ===========================================================================
int  memory_seg_select(BYTE  seg_no),
     memory_read_enable(BYTE  flag),
     memory_write_enable(BYTE  flag),
     video_mode_select(BYTE  video_mode),
     enable_vert_sync_interrupt(BYTE  flag),
     flash_video_memory(BYTE  color_entry);

// ===========================================================================
// 2X0(READ)		      status register functions
// ===========================================================================
int  external_video_exist(void),
     TV_system_type(void),
     vert_sync_int_occur(void),
     junior_exist(void),
     during_vert_sync_period(void),
     wait_vert_retrace_start(void);

// ===========================================================================
// 2X1(WRITE)		      corlor key register functions
// ===========================================================================
int  set_color_key(BYTE  color_key_ramdac_entry);

// ===========================================================================
// 2X2(WRITE)		       card ID register functions
// ===========================================================================
int  set_card_id(BYTE  card_id);
int  disable_card(void);

// ===========================================================================
// 2X3(WRITE)		      CRT select register functions
// ===========================================================================
int  select_crt_register(BYTE  crt_no),
     select_bank_segment(BYTE type, BYTE bank_no),
     select_bank_address(BYTE type, BYTE bank_no),
     select_bank(BYTE type, UINT yPos),
//     set_whole_display_color(BYTE  red_color, BYTE  green_color, BYTE  blue_color),
     set_whole_display_color(BYTE  color_entry),
     reset_whole_display_color(void),
     set_horz_shift_reg_msb(BYTE  flag),
     select_horizontal_width512(void),
     select_horizontal_width640(void),
     select_horizontal_width720(void),
     select_vertical_height400(void),
     select_vertical_height480(void),
     select_vertical_height510(void);

// ===========================================================================
// 2X8(WRITE)		       CRT data register functions
// ===========================================================================
int  set_vert_scroll_reg(BYTE  scan_start),
     set_horz_shift_reg(UINT  shift_pixel),
     // 11/05/93 Tang added
     set_screen_border_reg(BYTE  color_entry);

// ===========================================================================
// 2X4(WRITE)		  RAMDAC address write register functions
// ===========================================================================
int  set_ramdac_address_write_reg(BYTE	ramdac_address);

// ===========================================================================
// 2X7(WRITE)		  RAMDAC address read register functions
// ===========================================================================
int  set_ramdac_address_read_reg(BYTE  ramdac_address);

// ===========================================================================
// 2X5(READ / WRITE)	      RAMDAC data register functions
// ===========================================================================
int  set_ramdac_data_reg(BYTE  red_color, BYTE	green_color, BYTE  blue_color),
     get_ramdac_data_reg(BYTE  *red_color, BYTE  *green_color, BYTE  *blue_color);

// ===========================================================================
// 2X6(WRITE)		   RAMDAC input mask register functions
// ===========================================================================
int  set_ramdac_input_mask_reg(BYTE  mask_value);

// ---------------------------------------------------------------------------
//			   miscellaneous routines
// ---------------------------------------------------------------------------
int		init_ramdac_entry(void),
		set_underscan_mode(void),
		set_overscan_mode(void);
void		init_interrupt(void),
		restore_interrupt(void);
void interrupt	new_interrupt(void);
void            set_int_mask(BYTE bIRQ);

/* 11/05/93 Tang added for Hardware update */
void            myoutportb(unsigned portid, unsigned char value);
unsigned char   myinportb(unsigned portid);
/* 11/05/93 Tang added for Hardware update */

int  clear_TVscreen(void),
     set_TVscreen_color(BYTE  color_entry),
     jun_draw_point(UINT  x, UINT  y, BYTE  color_entry),
     jun_draw_line(UINT  x1, UINT  y1, UINT  x2, UINT  y2, BYTE  color_entry),
     jun_draw_rect(UINT  x, UINT  y, UINT  width, UINT	height,
		   BYTE  color_entry, UINT  fill_flag),
     jun_draw_rect2(UINT  x, UINT  y, UINT  width, UINT	height,
		   BYTE  color_entry, UINT  fill_flag),
     jun_draw_color_bar(int  pitch, int  color_no, BYTE  color_bar[]),
     jun_draw_slant_bar(int  pitch, int  color_no, BYTE  color_bar[], int dirt),
     jun_draw_circle(UINT  x, UINT  y, UINT  radius, BYTE  color_entry, UINT  fill_flag),
     jun_draw_circle2(UINT  x, UINT  y, UINT  radius, BYTE  color_entry, UINT  fill_flag),
     jun_draw_ellipse(UINT  x, UINT  y, UINT  xradius, UINT  yradius, BYTE  color_entry, UINT  fill_flag),
     jun_putchar(UINT  x, UINT	y, BYTE  ch, BYTE  color_entry),
     jun_putstring(UINT  x, UINT  y, BYTE  *str, BYTE  color_entry),
     jun_flood_fill(UINT x, UINT y, BYTE nColor);

// 10/06 Tang added for juntest.c user interface
int  DefaultTest(void),
     CustomerTest(void),
     ExitProgram(void),
     CheckCardExist(void),
     CheckVideoExist(void),
     VsyncInterrupt(void),
     FlashMemory(void),
     VideoMemoryRW(void),
     VideoModeSwitch(void),
     RamdacRW(void),
     VerticalScroll(void),
     HorizontalShift(void),
     DisplayAdjust(void);

void SetupWindow(int,int,int,int,char *,char [],int);
void PopupMainMenu(void),
     SelectTest(void),
     SetupMainScreen(void),
     InitialResultArea(void);
void InvertText(int,int,char [],int);
void DrawBorder(int,int,int,int,int,int) ;
void GetRepeatTime(void),
     UpdateRepeatTime(void),
     UpdateCheckBox(int,int,int),
     UpdateQC(int),
     ClearResultArea(void),
     thickborder(int),
     thinborder(int);
void ActiveFunc(int);
void ShowTime(void), ShowDate(void), ShowStatus(void);
int  hor_menusel(int,int,int,int,char *[],char [],int),
     GetMenuSelect(int,int,int,char *[],char [],int,char *[]);
//void setupmainscreen();
void scrollup(int,int,int,int),
     scrolldown(int,int,int,int);
int  get_dec_int(int,int,int,int),
     get_hex_int(int,int,int,int),
     get_string(int,int,int,char [],char [],int),
     get_keyin(int,int);

int  GetVideoMode(void);
int  AskUser(char *);
int  RunTest(void);
void MessageOut(int, char *),
     ShowResultMsg(char *);
int  WaitForResponse(int),
     Wait(int);
int  ScanKeybd(void);
void ControlKey(void);

void main(int argc, char *argv[]);

/* 12/04/93 Tang added */
int  set_bank_address(BYTE type);
int  set_bank_address1(BYTE type, BYTE pos);
