
// **************************************************************************
// Project : junior.prj
// File    : global.h
// Object  : declaration of global variables for reference by all modules
// Author  : Ricky Hsu
// Date    : 820810
// **************************************************************************


// ---------------------------------------------------------------------------
//                       system related parameters
// ---------------------------------------------------------------------------
extern BYTE far
          *video_memory;         // segment address of memory space(64K)
extern UINT
          io_base_address,       // base address of I/O registers
          card_id,               // card ID of Junior
          irq_line,              // hardware interrupt line(IRQ)
          color_key,             // RAMDAC entry of color key
          horz_disp_start_u,     // horizontal display start(underscan)
          horz_disp_stop_u,      // horizontal display stop(underscan)
          horz_disp_start_o,     // horizontal display start(underscan)
          horz_disp_stop_o,      // horizontal display stop(underscan)
          vert_scan_start,       // vertical scan start(vertical scroll)
          horz_shift_pixel,      // horizontal shift pixel number
          scan_mode;             // 0 : underscan, 1 : overscan


extern BYTE
       palette_table[256][3];                 // color values of RAMDAC

extern UINT
       mask[16],
       *jun_char_set[]; // character set table

extern UINT
       system_option[OPT_NUM];// system option table

// ---------------------------------------------------------------------------
//                addresses of I/O registers of Overlay Junior
// ---------------------------------------------------------------------------
extern UINT
       control_reg,           // 2X0 : control register
       status_reg,            // 2X0 : status register
       color_key_reg,         // 2X1 : color key register
       card_id_reg,           // 2X2 : card ID register
       crt_sel_reg,           // 2X3 : CRT select register
       crt_data_reg,          // 2X4 : CRT data register
       ramdac_addr_write_reg, // 2X5 : RAMDAC address write register
       ramdac_addr_read_reg,  // 2X6 : RAMDAC address read register
       ramdac_data_reg,       // 2X7 : RAMDAC data register
       ramdac_input_mask_reg; // 2X8 : RAMDAC input mask register

// ---------------------------------------------------------------------------
//                 values of I/O registers of Overlay Junior
// ---------------------------------------------------------------------------
extern BYTE
       control_reg_val,           // value of control register
       status_reg_val,            // value of status register
       color_key_reg_val,         // value of color key register
       card_id_reg_val,           // value of card ID register
       crt_sel_reg_val,           // value of CRT select register
       crt_data_reg_val,          // value of CRT data register
       ramdac_addr_write_reg_val, // value of RAMDAC address write register
       ramdac_addr_read_reg_val,  // value of RAMDAC address read register
       ramdac_input_mask_reg_val; // value of RAMDAC input mask register

extern ULONG
       ramdac_data_reg_val;       // value of RAMDAC data register

extern int
       attribute,
       invattr,
       msg_attr,
       val_attr,
       nosave,
       item_no,
       pattern_rw,
       scr_setupok,
       pickornot[9],
       teststatus[9],
       repeatime[2],
       nItemMain,
       nItemUser,
       xStart,
       xEnd,
       yStart,
       yEnd,
       yNow,
       xShow;

extern char
       *sPass,
       *sFail;

extern RECT
       rect;

extern POINT
       point;

extern unsigned long
       enter_interrupt;

extern int  ynouse, yheight, sstart, fScroll;

/* 12/04/93 Tang added */
extern int  bank_type, bank_pos;
