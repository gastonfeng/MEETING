// **************************************************************************
// Project : junior.prj
// File    : junior.c
// Object  : main module
// Author  : Ricky Hsu
// Date    : 820810
// **************************************************************************


#ifdef VGA_DISPLAY
  #include  <graphics.h>
#endif


#include  <stdio.h>
#include  <string.h>
#include  <dos.h>
#include  <stdlib.h>
#include  <conio.h>
#include  <time.h>
#include  "junior2.h"
#include  "extern.h"

int  test_routines(void);

int  test_junior_exist(void)
{
  int  entry_no, errflag;
  BYTE temp_id;
  char p[40];
  BYTE	old_r, old_g, old_b, new_r, new_g, new_b;
  long  rgb;

  errflag = FALSE;
  if ( ! junior_exist() ) {
     MessageOut(xShow+1, "Junior card not exist!");
     return(FALSE);
//     errflag = TRUE;
  }
  ShowStatus();

  entry_no = 0x80;
  // save old setting
  set_ramdac_address_read_reg(entry_no);
  get_ramdac_data_reg(&old_r, &old_g, &old_b);

  // write new value
  set_ramdac_address_write_reg(entry_no);
  set_ramdac_data_reg(0x1f, 0x2f, 0x3f);
  // read new value
  set_ramdac_address_read_reg(entry_no);
  get_ramdac_data_reg(&new_r, &new_g, &new_b);

  if ( new_r != 0x1f ||  new_g != 0x2f || new_b != 0x3f ) {
      sprintf(p, "Error in card ID %3d", card_id);
      MessageOut(xShow+1, p);
      errflag = TRUE;
  }
//  set_ramdac_address_write_reg((BYTE)entry_no);
//  set_ramdac_data_reg(0x00, 0x00, 0x3f);

  temp_id = 8;
  ShowStatus();
  set_card_id(temp_id);
  ShowStatus();
  // write new value
  set_ramdac_address_write_reg(entry_no);
  set_ramdac_data_reg(0x3f, 0x2f, 0x1f);
  // read new value
  set_ramdac_address_read_reg(entry_no);
  get_ramdac_data_reg(&new_r, &new_g, &new_b);

  if ( new_r == 0x3f &&  new_g == 0x2f && new_b != 0x1f ) {
      sprintf(p, "Error in card ID %3d", temp_id);
      MessageOut(xShow+1, p);
      errflag = TRUE;
  }

  //restore card id
  set_card_id(card_id);
  // restore old value
  set_ramdac_address_write_reg(entry_no);
  set_ramdac_data_reg(old_r, old_g, old_b);

  /* for later items use */
  video_mode_select(OVERLAY);

  ShowStatus();
  return( (errflag^=1) );     //excursive-or XOR
}


int  test_external_video_exist(void)
{
  int  xLeft, yTop, xRight, yBottom, xWidth, yHeight, xMax, yMax;
  int  i, nColor, errflag;
  char p[40];

  errflag = FALSE;
  if ( ! external_video_exist() ) {
     MessageOut(xShow+1, "External video not exist!");
     errflag = FALSE;
  }
#ifdef VGA_DISPLAY
cleardevice();
xMax = 640;
yMax = 480;
#else
xMax = 1024;
yMax = 512;
#endif

  randomize();	 //Initialize the random number generator
  for ( i=0; i<300; i++ ) {
     xLeft    = random(xMax);
     yTop     = random(yMax);
     xRight   = random(xMax);
     yBottom  = random(yMax);
     nColor   = random(255)+1;
     // test draw line
     jun_draw_line( xLeft, yTop, xRight, yBottom, nColor);
  }

  if ( !WaitForResponse(1) ) return(FALSE);

  jun_draw_rect( 200, 100,  824, 412, color_key, TRUE);

  return( (errflag^=1) );     //excursive-or XOR
}


int  test_vert_sync_int(void)
{
   time_t  first, second;
   char p[60];
   int count, errflag, imr_value;
   BYTE status_reg;

   errflag = FALSE;

   /* Step 1. Test Vsync period by polling status reg. bit 4 */
   count = 0;
//   wait_vert_retrace_start();
   first = time(NULL);  /* Gets system time */
   do {
      /* polling Vsync to ask Vsync is generated */
//      while ( ! during_vert_sync_period() ) ;
      wait_vert_retrace_start();
      delay(1);  //delay 1ms
      count++;
      second = time(NULL); /* Gets system time again */
   /* calculates the elapsed time in seconds, return as a double */
  } while ( difftime(second,first) < 2 ); //wait for 1 second

  MessageOut(xShow+1, "Vsync [period] after 2 secs");
  sprintf(p, "=> %d times", count);
  MessageOut(xShow+1, p);

  /* Step 2. Test Vsync interrupt with ISR(junaux.c) */
// read IMR
  imr_value = inportb(0x21);
  sprintf(p, "original IMR %x ", imr_value);
  MessageOut(xShow+1, p);

  imr_value = inportb(0x21);
  sprintf(p, "after set mask IMR %x ", imr_value);
  MessageOut(xShow+1, p);

  enter_interrupt = 0;
  count = 0;

  // enable interrupt
  // 11/05/93 Tang masked
  enable_vert_sync_interrupt(TRUE);
  // 11/05/93 Tang masked
  imr_value = inportb(0x21);
  sprintf(p, "enable int IMR %x ", imr_value);
  MessageOut(xShow+1, p);

  ShowStatus();
  status_reg = inport(0x280);
  /* wait vertical sync pulse start */
//  while ( ! during_vert_sync_period() ) ;
//  wait_vert_retrace_start();
  first = time(NULL);  /* Gets system time */
  do {
//     if ( ! vert_sync_int_occur() )  { //INTEN is cleared
        // wait_vert_retrace_start();  // if int occur, break & wait too long
        // delay(1);
//	enable_vert_sync_interrupt(TRUE);
	count++ ;
//     }
     second = time(NULL); /* Gets system time again */
     /* calculates the elapsed time in seconds, return as a double */
  } while ( difftime(second,first) < 2 ); //wait for 1 second

  // disable interrupt
  disable();
  // 11/05/93 Tang masked
  enable_vert_sync_interrupt(FALSE);
  // 11/05/93 Tang masked
  enable();

  // read IMR
  imr_value = inportb(0x21);
  sprintf(p, "gameover IMR %x ", imr_value);
  MessageOut(xShow+1, p);

  ShowStatus();

  MessageOut(xShow+1, "Vsync [interrput] after 2 secs");
  sprintf(p, "=> %d times,", enter_interrupt);
  MessageOut(xShow+1, p);
  sprintf(p, "   %d ", count);  //allow only one argument
  MessageOut(xShow+1, p);
  /* Fv = 60 Hz, so 60 times at 1 second period, error allow to 1 */
  if ( (enter_interrupt>=125) || (enter_interrupt<=115) ) {
     sprintf(p, "Error in IRQ %2d ", irq_line);
     MessageOut(xShow+1, p);
     errflag = TRUE;;
  }

  return( (errflag^=1) );     //excursive-or XOR
}

int  test_flash_memory(void)
{
  int  i, j, errflag;

  errflag = FALSE;
//  video_mode_select(OVERLAY);

  MessageOut(xShow+1, " flash to GREEN ?");
  flash_video_memory(JUN_GREEN);
  if ( !WaitForResponse(2) ) return(FALSE);
  MessageOut(xShow+1, " flash to Color Key ?");
  flash_video_memory(color_key);
  if ( !WaitForResponse(2) ) return(FALSE);
  MessageOut(xShow+1, " flash to RED ?");
  flash_video_memory(JUN_RED);
  if ( !WaitForResponse(2) ) return(FALSE);
  MessageOut(xShow+1, " flash to Color Key ?");
  flash_video_memory(color_key);
  if ( !WaitForResponse(2) ) return(FALSE);

  MessageOut(xShow+1, " Color Bar & Color Key");

  test_graphics();

  return( (errflag^=1) );     //excursive-or XOR
}

// **************************************************************************
//  test_ramdac() : test RAMDAC to check if all the entries are same as
//		    system palette table
//  return : TRUE  ==>	success
//	     FALSE ==>	error
// **************************************************************************
int  test_ramdac(void)
{
  BYTE	red_color, green_color, blue_color;
  int	i, errflag, entry_no;
  BYTE	old_r, old_g, old_b, new_r, new_g, new_b, tmp_r, tmp_g, tmp_b;
  char	p[40];

  errflag = FALSE;
  set_ramdac_address_read_reg(1); // set the first RAMDAC entry to read

  for(i=1; i<256; i++) {
      // get a RAMDAC entry
      get_ramdac_data_reg(&red_color, &green_color, &blue_color);
      // compare the entry value with that of palette table
      if ( palette_table[i][RED_PART]	!= red_color ||
	   palette_table[i][GREEN_PART] != green_color ||
	   palette_table[i][BLUE_PART]	!= blue_color ) {
	ShowStatus();
	sprintf(p, "Error in read entry %3d", i);
	MessageOut(xShow+1, p);
	errflag = TRUE;
	ControlKey();
	if ( !WaitForResponse(1) )  return(FALSE);
      }
  } // for(i=0; i<256; i++)

  randomize();	 //Initialize the random number generator
  for ( i=0; i<5; i++) {
     entry_no = (BYTE)random(256);  //generate a random no.
     // save old setting
     set_ramdac_address_read_reg(entry_no);
     get_ramdac_data_reg(&old_r, &old_g, &old_b);

     // write new value
     set_ramdac_address_write_reg(entry_no);
     tmp_r = (BYTE)random(63);	//0x3f
     tmp_g = (BYTE)random(63);
     tmp_b = (BYTE)random(63);
     set_ramdac_data_reg(tmp_r, tmp_g, tmp_b);
     // read new value
     set_ramdac_address_read_reg(entry_no);
     get_ramdac_data_reg(&new_r, &new_g, &new_b);

     if ( new_r != tmp_r || new_g != tmp_g || new_b != tmp_b ) {
	sprintf(p, "Error in R/W entry %3d", entry_no);
	MessageOut(xShow+1, p);
	errflag = TRUE;
     }
     // restore old value
     set_ramdac_address_write_reg(entry_no);
     set_ramdac_data_reg(old_r, old_g, old_b);
  }

  /* draw vert. lines from right to left */
  for ( i=VIDEO_MEMORY_WIDTH - 1; i>=0; i--)
     jun_draw_line(i, 0, i, VIDEO_MEMORY_HEIGHT-1, JUN_UNKNOWN);
  /* draw horz. lines from bottom to top */
  for ( i=VIDEO_MEMORY_HEIGHT - 1; i>=0; i--)
     jun_draw_line(0, i, VIDEO_MEMORY_WIDTH-1, i, color_key);

  return( (errflag^=1) );     //excursive-or XOR
} // end function test_ramdac(void)


// **************************************************************************
//  test_video_memory() : test video memory
//  return : TRUE  ==>	success
//	     FALSE ==>	error
// **************************************************************************
int  test_video_memory(void)
{
  BYTE	seg_no, bank_no, count, loop_times;
  int	i, j, errflag;
  char	p[40];
  char test_pat[4] = {0x55, 0xaa, 0x33, 0xcc};

  errflag = FALSE;
//  video_mode_select(OVERLAY); // set video mode to computer only
  ShowStatus();

  switch ( bank_type ) {
     case BANK_SIZE_64K :
          count = 64;
          loop_times = 1;
          break;
     case BANK_SIZE_16K :
          count = 16;
          loop_times = 4;
          break;
     case BANK_SIZE_8K :
          count = 8;
          loop_times = 8;
          break;
  }

  for (seg_no=0; seg_no<8; seg_no++)
    {
      // select a video memory segment
      memory_seg_select(seg_no);

      for ( bank_no= 0; bank_no<loop_times; bank_no++) {
         select_bank_segment(bank_type, bank_no);

         // fill this segment with pattern 0x55
         sprintf(p, "Test pattern 0x55");
         MessageOut(xShow+1, p);
         for(i=0; i<count; i++)
	    for(j=0; j<1024; j++)
	       video_memory[(i<<10) + j] = 0x55;

         // check if this segment if full of pattern 0x55
         for(i=0; i<count; i++)
	    for(j=0; j<1024; j++)
	       if ( video_memory[(i<<10) + j] != 0x55 )
	       {
//Tang	          printf("Error in video memory testing : segment %d\n", seg_no);
	          MessageOut(xShow+1, "Error in R/W 0x55!" );
	          sprintf(p, " at segment %d, bank %d ", seg_no, bank_no);
	          MessageOut(xShow+1, p);
	          errflag = TRUE;
	          break;
               }

         // fill this segment with pattern 0xaa
         sprintf(p, "Test pattern 0xAA");
         MessageOut(xShow+1, p);
         for(i=0; i<count; i++)
	    for(j=0; j<1024; j++)
	       video_memory[(i<<10) + j] = 0xaa;

         // check if this segment if full of pattern 0xaa
         for(i=0; i<count; i++)
	    for(j=0; j<1024; j++)
	       if ( video_memory[(i<<10) + j] != 0xaa )
	       {
//Tang	          printf("Error in video memory testing : segment %d\n", seg_no);
	          MessageOut(xShow+1, "Error in R/W 0xAA!" );
	          sprintf(p, " at segment %d, bank %d ", seg_no, bank_no);
	          MessageOut(xShow+1, p);
	          errflag = TRUE;
	          break;
	       }

         // test new pattern input
         if ( pattern_rw != 0 ) {
	    // fill this segment with pattern 0xaa
	    sprintf(p, "Test pattern 0x%2X!", pattern_rw);
	    MessageOut(xShow+1, p);
	    for(i=0; i<count; i++)
	       for(j=0; j<1024; j++)
	          video_memory[(i<<10) + j] = (BYTE)pattern_rw;

	    // check if this segment if full of pattern 0xaa
	    for(i=0; i<count; i++)
	       for(j=0; j<1024; j++)
	          if ( video_memory[(i<<10) + j] != (BYTE)pattern_rw )
	          {
//Tang		     printf("Error in video memory testing : segment %d\n", seg_no);
		     sprintf(p, "Error in R/W %2X!" , pattern_rw);
		     MessageOut(xShow+1, p);
	             sprintf(p, " at segment %d, bank %d ", seg_no, bank_no);
		     MessageOut(xShow+1, p);
		     errflag = TRUE;
		     break;
                  }
         }
      } /* end of for (bank_no) */

    } // for(i=0; i<8; i++)

//12/24/93 Tang added
    /* test memory read disable */
    for(i=0; i<count; i++)
       for(j=0; j<1024; j++)
          video_memory[(i<<10) + j] = test_pat[j%4];

    memory_read_enable(FALSE);

    for(i=0; i<count; i++)
       for(j=0; j<1024; j++)
          if ( video_memory[(i<<10) + j] == test_pat[j%4] ) {
	     MessageOut(xShow+1, "Error in memory read disable !" );
	     sprintf(p, " at segment %d, line %d ", seg_no, i);
	     MessageOut(xShow+1, p);
             errflag = TRUE;
             break;
          }
    memory_read_enable(TRUE);
    /* test memory write disable */
    memory_write_enable(FALSE);
    // fill this segment with pattern 0x99
    for(i=0; i<count; i++)
       for(j=0; j<1024; j++)
          video_memory[(i<<10) + j] = 0x99;
    // check if this segment if full of pattern 0x99
    for(i=0; i<count; i++)
       for(j=0; j<1024; j++)
          if ( video_memory[(i<<10) + j] == 0x99 ) {
	     MessageOut(xShow+1, "Error in memory write disable !" );
	     sprintf(p, " at segment %d, line %d ", seg_no, i);
	     MessageOut(xShow+1, p);
	     errflag = TRUE;
	     break;
          }
    memory_write_enable(TRUE);

//Tang	printf("OK\n");
  return( (errflag^=1) );     //excursive-or XOR
} // end function test_video_memory(void)

// **************************************************************************
//  test_video_mode() : test video mode
//			COMPUTER ONLY and OVERLAY
//  return : TRUE  ==>	success
//	     FALSE ==>	error
// **************************************************************************
int  test_video_mode(void)
{
  int  x, y, i;

  // -------------------------------------------------------------------------
  //			    testing overlay mode
  // -------------------------------------------------------------------------
  // set video mode to overlay mode
  video_mode_select(OVERLAY);
  // setting TV screen to different colors
  MessageOut(xShow+1, "Set TV screen colors" );

  set_TVscreen_color(JUN_MAGENTA);
  MessageOut(xShow+2, "TV screen MAGENTA ?" );
  if ( !WaitForResponse(2) ) return(FALSE);

  set_TVscreen_color(JUN_CYAN);
  MessageOut(xShow+2, "TV screen CYAN ?" );
  if( !WaitForResponse(2) )  return(FALSE);

  // let video source input occupies entire TV screen
  reset_whole_display_color();

  // setting TV screen to different scan mode
  MessageOut(xShow+1, "Change scan mode" );

  // set video mode to overlay
//  video_mode_select(OVERLAY);

  flash_video_memory(color_key);

  set_screen_border_reg(JUN_GREEN);

  MessageOut(xShow+2, "Overscan mode ?" );
  if ( !WaitForResponse(2) )  return(FALSE);

//  set_overscan_mode();
  for ( i=0; i<8; i+=2 )
     jun_draw_rect( 0, (i+1)*64, 1023, 63, i+1, TRUE);

  if( !WaitForResponse(2) )  return(FALSE);

  MessageOut(xShow+2, "Change to Underscan mode ?" );
  set_underscan_mode();
  if ( !WaitForResponse(2) )  return(FALSE);

  for ( i=0; i<8; i+=2 )
     jun_draw_rect( 0, (i+1)*64, 1023, 63, 7-i, TRUE);
  if( !WaitForResponse(3) )  return(FALSE);

  MessageOut(xShow+2, "Reset to Overscan mode." );
  set_overscan_mode();

//  printf("Testing Video Mode : OVERLAY\n");
  MessageOut(xShow+1, "Video mode : OVERLAY ?" );

//  flash_video_memory();
  jun_draw_rect(  0,  0, 1023, 511, JUN_YELLOW, TRUE);

  jun_draw_rect(  0,  0, 400, 240, color_key, TRUE);

//  MessageOut(xShow+1, "TV screen shows overlay ?" );

  if( !WaitForResponse(1) )  return(FALSE);

  MessageOut(xShow+2, "Panning window ?" );
  /* move rect. to right */
  for ( x=0; x<400; x++) {
    ControlKey();
    jun_draw_line( x+400, 0, x+400, 240-1, color_key);
    jun_draw_line(     x, 0,	 x, 240-1, JUN_YELLOW);
  }
  /* move rect. to down */
  for ( y=0; y<240; y++) {
    ControlKey();
    jun_draw_line( 400, y+240, 800-1, y+240, color_key);
    jun_draw_line( 400,     y, 800-1,	  y, JUN_YELLOW);
  }
  /* move rect. to left */
  for ( x=400-1; x>=0; x--) {
    ControlKey();
    jun_draw_line(     x, 240,	   x, 480-1, color_key);
    jun_draw_line( x+400, 240, x+400, 480-1, JUN_YELLOW);
  }
  /* move rect. to up */
  for ( y=240-1; y>=0; y--) {
    ControlKey();
    jun_draw_line( 0,	  y, 400-1,	y, color_key);
    jun_draw_line( 0, y+240, 400-1, y+240, JUN_YELLOW);
  }

  if( !WaitForResponse(1) )  return(FALSE);

  // -------------------------------------------------------------------------
  //			    testing video only mode
  // -------------------------------------------------------------------------
//Tang	printf("Testing Video Mode : VIDEO ONLY\n");
  MessageOut(xShow+1, "Video mode : VIDEO ONLY ?" );
  // set video mode to video only
  video_mode_select(EXTERNAL_VIDEO_ONLY);

  if( !WaitForResponse(2) )  return(FALSE);

  MessageOut(xShow+1, "Reset to OVERLAY mode" );
  // set video mode to video only
  video_mode_select(OVERLAY);

  if( !WaitForResponse(1) )  return(FALSE);

  jun_draw_rect(  0,  0, 1023, 511, color_key, TRUE);

//  printf("OK\n");

  return(TRUE);
} // end function test_video_mode(void)


// **************************************************************************
//  test_vertical_scroll() : test vertical scroll function
// **************************************************************************
int  test_vertical_scroll(void)
{
  int  y=0, height=32, i, yNouse;
  int  xLeft, yTop, xRight, yBottom, xWidth, yHeight, xMax, yMax;
  int  nColor, errflag;
  BYTE bVertScanStart;

#ifdef VGA_DISPLAY
cleardevice();
xMax = 640;
yMax = 480;
#else
xMax = 1024;
yMax = 512;
#endif


  // set video mode to overlay
//  video_mode_select(OVERLAY);

  randomize();	 //Initialize the random number generator
  for ( i=0; i<50; i++ ) {
     xLeft    = random(xMax);
     yTop     = random(yMax);
     xWidth   = random( min(xMax-xLeft, 512) );
     yHeight  = random( min(yMax-yTop,	256) );
     nColor   = random(255)+1;
//     fFill	= random(2);
     // test draw rectangle
     jun_draw_rect( xLeft, yTop, xWidth, yHeight, nColor, TRUE);
  }
  nColor = random(255)+1;
  jun_draw_rect(  0, yMax-64, xMax, 64, nColor, TRUE);

  if ( !WaitForResponse(1) ) return(FALSE);

  // fill TV screen with many rectangles
  /*
  jun_draw_rect(  0,  y, 1024, height, JUN_RED, 	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_GREEN,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_BLUE,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_YELLOW,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_WHITE,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_BLACK,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_CYAN,	TRUE);	   y += height;

  jun_draw_rect(  0,  y, 1024, height, JUN_RED, 	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_GREEN,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_BLUE,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_YELLOW,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_WHITE,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_BLACK,	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_CYAN,	TRUE);	   y += height;

  jun_draw_rect(  0,  y, 1024, height, JUN_RED, 	TRUE);	   y += height;
  jun_draw_rect(  0,  y, 1024, height, JUN_GREEN,	TRUE);	   y += height;
  */

  MessageOut(xShow+1, "TV screen scroll up ?" );
  if( !WaitForResponse(1) )  return(FALSE);

  // scroll up ==> by increasing vertical scroll register value
  bVertScanStart = vert_scan_start;
  for(i=0; i<0x100; i++)
    {
      wait_vert_retrace_start();
      set_vert_scroll_reg(++bVertScanStart);
//	delay(1);   /* delay 0.001 sec */
    }

  MessageOut(xShow+1, "TV screen scroll down ?" );
  if( !WaitForResponse(1) )  return(FALSE);

  // scroll down ==> by decreasig vertical scroll register value
  for(i=0; i<0x100; i++)
    {
//      wait_vert_retrace_start();
      set_vert_scroll_reg(--bVertScanStart);
	delay(1);  /* delay 0.001 sec */
    }

  MessageOut(xShow+1, "Moving effect !" );
  if( !WaitForResponse(2) )  return(FALSE);

  // restore to original value
  vert_scan_start = system_option[9];
  set_vert_scroll_reg(vert_scan_start);

//  jun_draw_rect(  0,	0, 1024, 512, JUN_RED, TRUE);
/*
  y = 0; height = 6;
  yNouse = vert_scan_start*height + 480;
  for ( i=0; i<480/2; i++ ) {
     if ( yNouse >= 512 )  yNouse = 0;
     nColor = random(255)+1;
     jun_draw_rect(  0,  yNouse, 1024, height, nColor, TRUE);
     yNouse += height;
     wait_vert_retrace_start();
     set_vert_scroll_reg((BYTE)i*height/2);
   }
   */
  fScroll = TRUE;
  yheight = 8;
  ynouse = bVertScanStart*yheight + 480;
  enable_vert_sync_interrupt(TRUE);
  sstart=0;

  if ( teststatus[2] )  {     // Vsync interrupt test is true
     set_int_mask(irq_line);
     while ( fScroll )
       enable_vert_sync_interrupt(TRUE);
  }

  fScroll = FALSE;
  enable_vert_sync_interrupt(FALSE);

  // restore to original value
  vert_scan_start = system_option[9];
  set_vert_scroll_reg(vert_scan_start);

  return(TRUE);
} // end function test_vertical_scroll(void)

// **************************************************************************
//  test_horz_shift() : test horizontal shift function
// **************************************************************************
int  test_horz_shift(void)
{
    int  x=0, width=64, i;
  int  xCnt, yCnt, nRadius, xMax, yMax;
  int  nColor, fFill, errflag;
  UINT wHorzScanStart;

#ifdef VGA_DISPLAY
cleardevice();
xMax = 640;
yMax = 480;
#else
xMax = 1024;
yMax = 512;
#endif

  // set video mode to overlay
//  video_mode_select(OVERLAY);

  randomize();	 //Initialize the random number generator
  for ( i=0; i<50; i++ ) {
     xCnt     = random(xMax);
     yCnt     = random(yMax);
     nRadius  = random( min( min(xMax-xCnt,xCnt), min(yMax-yCnt, yCnt) ));
     nColor   = random(255)+1;
     fFill    = random(2);
     // test draw rectangle
     jun_draw_circle2( xCnt, yCnt, nRadius, nColor, TRUE);
  }
  nColor = random(255)+1;
  jun_draw_rect( xMax-128, 0, 128, yMax, nColor, TRUE);

  if ( !WaitForResponse(1) ) return(FALSE);

  // fill TV screen with many rectangles
  /*
  jun_draw_rect(  x,  0, width, 512, JUN_RED,	  TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_GREEN,   TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_BLUE,	  TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_YELLOW,  TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_WHITE,   TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_BLACK,   TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_CYAN,	  TRUE);	 x += width;

  jun_draw_rect(  x,  0, width, 512, JUN_RED,	  TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_GREEN,   TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_BLUE,	  TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_YELLOW,  TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_WHITE,   TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_BLACK,   TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_CYAN,	  TRUE);	 x += width;

  jun_draw_rect(  x,  0, width, 512, JUN_RED,	  TRUE);	 x += width;
  jun_draw_rect(  x,  0, width, 512, JUN_GREEN,   TRUE);	 x += width;
  */

  MessageOut(xShow+1, "TV screen shift left ?" );
  if( !WaitForResponse(1) )  return(FALSE);

  // scroll left ==> by increasing horizontal shift register value
  wHorzScanStart = horz_shift_pixel;
  for(i=0; i<0x200; i++)
    {
//      wait_vert_retrace_start();
//      horz_shift_pixel += 2;
//      set_horz_shift_reg(horz_shift_pixel);
      set_horz_shift_reg(++wHorzScanStart);
      delay(1);   /* delay 0.001 sec */
    }

  MessageOut(xShow+1, "TV screen shift right ?" );
  if( !WaitForResponse(1) )  return(FALSE);

  // scroll right ==> by decreasing horizontal shift register value
  for(i=0; i<0x200; i++)
    {
//      wait_vert_retrace_start();
//      horz_shift_pixel -= 2;
//      set_horz_shift_reg(horz_shift_pixel);
      set_horz_shift_reg(--wHorzScanStart);
      delay(1);   /* delay 0.001 sec */
    }

  // restore to original value
  horz_shift_pixel = system_option[10];
  set_horz_shift_reg(horz_shift_pixel);

  return(TRUE);
} // end function test_horz_shift(void)


// **************************************************************************
//  test_routines() : test all the auxiliary routines
// **************************************************************************
int  test_routines(void)
{
    BYTE  red_color, green_color, blue_color, imr_value, irr_value, isr_value;
    int   seg_no, i;

  // test video memory select routine
  for(seg_no=0; seg_no<8; seg_no++)
    {
      memory_seg_select(seg_no);
      printf("seg_no = %d, control_reg_val = %u\n", seg_no, control_reg_val);
    } // for(i=0; i<8; i++)

  // test video memory read/write enable/disable routines
  memory_read_enable(FALSE);
  memory_read_enable(TRUE);
  memory_write_enable(FALSE);
  memory_write_enable(TRUE);

  // test video mode select routine
  video_mode_select(OVERLAY);
  video_mode_select(EXTERNAL_VIDEO_ONLY);

  // test enable/disable vertical sync interrupt
  enable_vert_sync_interrupt(TRUE);
  enable_vert_sync_interrupt(FALSE);

  // test if Junior is present
  if ( junior_exist() == TRUE )
    printf("Overlay Junior exist\n");
  else
    printf("Overlay Junior not exist\n");

  // test if external video source exist
  if ( external_video_exist() == TRUE )
    printf("External video source exist\n");
  else
    printf("External video source not exist\n");

  // test color key register
  set_color_key(50);
  set_color_key(100);
  set_color_key(200);

  // test card ID register
  set_card_id(0);
  set_card_id(8);
  set_card_id(0x0f);

  // test CRT select register
  select_crt_register(VERT_SCROLL_REG_SEL);
//  select_crt_register(HORZ_DISP_START_REG_SEL);
//  select_crt_register(HORZ_DISP_STOP_REG_SEL);
  select_crt_register(HORZ_SHIFT_REG_SEL);

  // test horizontal shift register LSB
  set_horz_shift_reg_msb(1);
  set_horz_shift_reg_msb(0);

  // test reset the whole display to a certain color
  reset_whole_display_color();

  // test vertical scroll register
  set_vert_scroll_reg(0x00);
  set_vert_scroll_reg(0x10);
  set_vert_scroll_reg(0x80);
  set_vert_scroll_reg(0xff);

  // test horizontal display start and stop registers
  set_underscan_mode();
  set_overscan_mode();

  // test horizontal shift register
  set_horz_shift_reg(0x80);
  set_horz_shift_reg(0xff);
  set_horz_shift_reg(0x100);
  set_horz_shift_reg(0x1ff);

  // test RAMDAC address write register
  set_ramdac_address_write_reg(0x00);
  set_ramdac_address_write_reg(0x40);
  set_ramdac_address_write_reg(0x80);
  set_ramdac_address_write_reg(0xff);

  // test RAMDAC address read register
  set_ramdac_address_read_reg(0x00);
  set_ramdac_address_read_reg(0x40);
  set_ramdac_address_read_reg(0x80);
  set_ramdac_address_read_reg(0xff);

  // test RAMDAC data register
  set_ramdac_address_write_reg(0xff);
  set_ramdac_data_reg(0x3f, 0x00, 0x00);
  set_ramdac_address_read_reg(0xff);
  get_ramdac_data_reg(&red_color, &green_color, &blue_color);

  set_ramdac_address_write_reg(0xff);
  set_ramdac_data_reg(0x00, 0x3f, 0x00);
  set_ramdac_address_read_reg(0xff);
  get_ramdac_data_reg(&red_color, &green_color, &blue_color);

  set_ramdac_address_write_reg(0xff);
  set_ramdac_data_reg(0x00, 0x00, 0x3f);
  set_ramdac_address_read_reg(0xff);
  get_ramdac_data_reg(&red_color, &green_color, &blue_color);

  set_ramdac_address_write_reg(0xff);
  set_ramdac_data_reg(0x3f, 0x00, 0x3f);
  set_ramdac_address_read_reg(0xff);
  get_ramdac_data_reg(&red_color, &green_color, &blue_color);

  set_ramdac_address_write_reg(0xff);
  set_ramdac_data_reg(0x3f, 0x3f, 0x00);
  set_ramdac_address_read_reg(0xff);
  get_ramdac_data_reg(&red_color, &green_color, &blue_color);

  set_ramdac_address_write_reg(0xff);
  set_ramdac_data_reg(0x00, 0x3f, 0x3f);
  set_ramdac_address_read_reg(0xff);
  get_ramdac_data_reg(&red_color, &green_color, &blue_color);

  set_ramdac_address_write_reg(0xff);
  set_ramdac_data_reg(0x3f, 0x3f, 0x3f);
  set_ramdac_address_read_reg(0xff);
  get_ramdac_data_reg(&red_color, &green_color, &blue_color);

  // test clear TV screen
  clear_TVscreen();

  // test setting TV screen to different colors
  set_TVscreen_color(JUN_WHITE);
  set_TVscreen_color(JUN_BLUE);
  set_TVscreen_color(JUN_MAGENTA);
  set_TVscreen_color(JUN_RED);
  set_TVscreen_color(JUN_YELLOW);
  set_TVscreen_color(JUN_GREEN);
  set_TVscreen_color(JUN_CYAN);
  set_TVscreen_color(DEFAULT_COLOR);

  // read IMR
  imr_value = inportb(0x21);

  // read IRR
  outportb(0x20, 0x0a);
  irr_value = inportb(0x20);

  // read ISR
  outportb(0x20, 0x0b);
  isr_value = inportb(0x20);

  // test interrupt routine
  init_interrupt();

  test_graphics();

  restore_interrupt();

  return(TRUE);
} // end function test_routines(void)



int test_graphics(void)
{
  int  i, j, seg_no, pitch, color_no;
  BYTE	color_entry_table[256];

#ifdef VGA_DISPLAY
  {
       /* request auto detection */
       int gdriver = DETECT, gmode, errorcode;
       /* initialize graphics mode */
       initgraph(&gdriver, &gmode, "c:\\bc\\bgi");
       /* read result of initialization */
       errorcode = graphresult();
       if (errorcode != grOk)  /* an error occurred */
       {
	  printf("Graphics error: %s\n", grapherrormsg(errorcode));
	  printf("Press any key to halt:");
	  getch();
	  exit(1);	       /* return with error code */
       }
  }

#endif

//    video_mode_select(OVERLAY);

  // test putchar
  jun_putchar(	2,   0, 'A', JUN_YELLOW);
  jun_putchar( 10,  10, 'b', JUN_YELLOW);
  jun_putchar( 39,  23, 'c', JUN_YELLOW);
  jun_putchar( 20,  23, '-', JUN_YELLOW);
  jun_putchar( 30,  23, '+', JUN_YELLOW);

  if( !WaitForResponse(1) )  return(FALSE);

//getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif
  // test putstring
  jun_putstring( 2,  0, "abcdefghijklmnopqrstuvwxyz", JUN_WHITE);
//  jun_putstring( 0,  0, "abcdefghijklmnopqrstuvwxyz", DEFAULT_COLOR);

//getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif
  jun_putstring( 5,  5, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", JUN_BLACK);
//  jun_putstring( 5,  5, "ABCDEFGHIJKLMNOPQRSTUVWXYZ", DEFAULT_COLOR);

//getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif

  jun_putstring(10, 10, "012345678901234567890123456789", JUN_WHITE);
//  jun_putstring(10, 10, "012345678901234567890123456789", JUN_DEFAULT_COLOR);

//getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif

  jun_putstring(20, 20, "`~!@#$\%^&*()-_=+\\| ,<.>/?'\042;:[{]}", DEFAULT_COLOR);
//  jun_putstring(23, 23, "`~!@#$\%^&*()-_=+\\| ,<.>/?'\042;:[{]}", DEFAULT_COLOR);

  if( !WaitForResponse(2) )  return(FALSE);

//getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif

  // test draw circle
  jun_draw_circle(100, 100,  50, JUN_BLUE, FALSE);
  jun_draw_circle(100, 100, 100, JUN_GREEN, TRUE);
  for(i=10; i<240; i+=10)
    jun_draw_circle(319, 239,  i, JUN_CYAN, TRUE);
//  jun_draw_circle(319, 239,  20, JUN_YELLOW, TRUE);

#ifdef VGA_DISPLAY
circle(319, 239, 235);
#endif

//getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif

  // test draw circle
  jun_draw_ellipse(100, 100,  50, 30, JUN_BLUE, FALSE);
  jun_draw_ellipse(100, 100, 100, 60, JUN_GREEN, TRUE);
  for(i=10; i<315; i+=10)
    jun_draw_ellipse(319, 239,	i, 2*i/3, JUN_YELLOW, TRUE);

  if( !WaitForResponse(2) )  return(FALSE);

#ifdef VGA_DISPLAY
ellipse(319, 239, 0, 360, 319, 235);
#endif


//getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif

      color_entry_table[0] = JUN_WHITE;
      color_entry_table[1] = JUN_YELLOW;
      color_entry_table[2] = JUN_CYAN;
      color_entry_table[3] = JUN_GREEN;
      color_entry_table[4] = JUN_MAGENTA;
      color_entry_table[5] = JUN_RED;
      color_entry_table[6] = JUN_BLUE;
      color_entry_table[7] = JUN_BLACK;

#ifdef VGA_DISPLAY
      pitch	     = 80;
      color_no	     = 8;
#else
      pitch	     = 128;
      color_no	     = 8;
#endif

  // draw color bars
//  for(pitch=10; pitch<=80; pitch+=10)
  for(pitch=60; pitch<=80; pitch+=20)
    jun_draw_color_bar(pitch, color_no, color_entry_table);
//  video_mode_select(OVERLAY);

  if ( !WaitForResponse(1) )	return(FALSE);

  for(i=0; i<color_no; i++) {
    set_color_key(color_entry_table[i]);
    if ( !WaitForResponse(1) )	return(FALSE);
  }
  jun_draw_color_bar(639, color_no, color_entry_table);

//    video_mode_select(OVERLAY);

    jun_draw_slant_bar(80, color_no, color_entry_table, 0);

// 10/29 Tang
    jun_draw_slant_bar(110, color_no, color_entry_table, 1);
//    video_mode_select(OVERLAY);
    if ( !WaitForResponse(1) )  return(FALSE);
    for(i=0; i<color_no; i++) {
      set_color_key(color_entry_table[i]);
      if ( !WaitForResponse(1) )  return(FALSE);
    }
//    video_mode_select(OVERLAY);

    set_color_key(color_key);

/**********************************
getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif

  // test draw point
  jun_draw_point(  0,	0, GREEN);
  jun_draw_point( 10,  10, GREEN);
  jun_draw_point(100, 100, GREEN);
  jun_draw_point(200, 200, GREEN);
  jun_draw_point(600, 400, GREEN);
  jun_draw_point(639, 479, GREEN);

getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif

  // test draw line
  jun_draw_line(  0,   0, 200, 200, RED);      getch();
  jun_draw_line(479, 479, 220, 220, RED);      getch();
  jun_draw_line(479,   0, 200, 200, BLUE);     getch();
  jun_draw_line(  0, 479, 220, 220, BLUE);     getch();

  jun_draw_line(639,   0,   0, 479, YELLOW);   getch();
  jun_draw_line(  0,   0, 639, 479, YELLOW);   getch();
  jun_draw_line(  0, 240, 639, 240, YELLOW);   getch();
  jun_draw_line(320,   0, 320, 479, YELLOW);   getch();
  jun_draw_line(111,  39, 112, 479, YELLOW);   getch();
  jun_draw_line(111,  39, 639,	30, YELLOW);   getch();

  jun_draw_line(400,  10, 400,	10, GREEN);    // only 1 point

getch();
#ifdef VGA_DISPLAY
cleardevice();
#endif

  // test draw rectangle
  jun_draw_rect(  0,   0,  50,	50, RED, FALSE);
  jun_draw_rect( 50,  50,  50,	50, YELLOW, TRUE);
  jun_draw_rect(100, 100,  50,	50, BLUE, FALSE);
  jun_draw_rect(150, 150,  50,	50, GREEN, TRUE);
  jun_draw_rect(0,   200, 640,	50, CYAN, TRUE);
  jun_draw_rect(0,     0, 640, 480, YELLOW, TRUE);
*****************************/

//getch();
#ifdef VGA_DISPLAY
  closegraph();
#endif
  return(TRUE);

} /* test_graphics */

// **************************************************************************
//  set_system_option() : read "junior.ini" file to set system options
//  return : TRUE  ==>	success
//	     FALSE ==>	error
// **************************************************************************
int  set_system_option(void)
{
    char  temp[81];
    UINT  i;
    FILE  *ini_file;

  // open "junior.ini" file to read system options
  ini_file = fopen("junior.ini", "rt");
  if ( ini_file == NULL ) // "junior.ini" file not exist, use default
    {
      // set the values of system options to appropriate variables
      system_option[0]	= 0xd000;
      video_memory	= MK_FP(system_option[0], 0x00); // get a physical memory address
      io_base_address	= system_option[1]  = 0x280; // base address of I/O registers
      card_id		= system_option[2]  = 14; // card ID of Junior
      irq_line		= system_option[3]  = 4;  // hardware interrupt line(IRQ)
      color_key 	= system_option[4]  = JUN_BLUE; // RAMDAC entry of color key
      vert_scan_start	= system_option[5]  = 0; // vertical scan start(vertical scroll)
      horz_shift_pixel	= system_option[6] = 0; // horizontal shift pixel number
      scan_mode 	= system_option[7] = OVERSCAN_MODE;
      return(TRUE);
    }

  // get a string and analyze it
  i = 0;
  for(i=0; i<OPT_NUM; i++)
    {
      fgets(temp, 80, ini_file);
      temp[strlen(temp)-1] = '\0'; // get rid of '\n'
      set_option(temp, i);
    } // for(i=0; i<OPT_NUM; i++)

  // set the values of system options to appropriate variables
  video_memory	      = MK_FP(system_option[0], 0x00); // get a physical memory address
  io_base_address     = system_option[1];  // base address of I/O registers
  card_id	      = system_option[2];  // card ID of Junior
  irq_line	      = system_option[3];  // hardware interrupt line(IRQ)
  color_key	      = system_option[4];  // RAMDAC entry of color key
  vert_scan_start     = system_option[5];  // vertical scan start(vertical scroll)
  horz_shift_pixel    = system_option[6]; // horizontal shift pixel number
  scan_mode	      = system_option[7]; // 0 : underscan, 1 : overscan

  fclose(ini_file);
  return(TRUE);
} // end function set_system_option()

// **************************************************************************
//  set_option() : set individual option
// **************************************************************************
int  set_option(char  *option_string,
		UINT  option_index)
{
    char  option[81];

  switch( option_string[0] )
    {
      case  MEMORY_BASE : // set physical base memory segment
	    strcpy(option, option_string+3+strlen("memory_base="));
	    if ( option[0] == '\0' || strcmp(option, "default") == 0 ) // use default value
		system_option[option_index] = 0xd000;
	    else
		system_option[option_index] = hex_string_to_int(option);

	    break;

      case  IO_BASE : // set I/O base address
	    strcpy(option, option_string+3+strlen("io_base="));
	    if ( option[0] == '\0' || strcmp(option, "default") == 0 ) // use default value
		system_option[option_index] = 0x280;
	    else
		system_option[option_index] = hex_string_to_int(option);

	    break;

      case  CARD_ID : // set card ID
	    strcpy(option, option_string+3+strlen("card_ID="));
	    if ( option[0] == '\0' || strcmp(option, "default") == 0 ) // use default value
		system_option[option_index] = 14;
	    else
		system_option[option_index] = atoi(option);

	    break;

      case  IRQ : // set IRQ line
	    strcpy(option, option_string+3+strlen("IRQ="));
	    if ( option[0] == '\0' || strcmp(option, "default") == 0 ) // use default value
		system_option[option_index] = 4;
	    else
		system_option[option_index] = atoi(option);

	    break;

      case  COLOR_KEY : // set RAMDAC entry of color key
	    strcpy(option, option_string+3+strlen("color_key="));
	    if ( option[0] == '\0' || strcmp(option, "default") == 0 ) // use default value
		system_option[option_index] = JUN_BLUE; // 36
	    else
		system_option[option_index] = atoi(option);

	    break;

      case  VERTICAL_SCAN_START :
	    strcpy(option, option_string+3+strlen("vertical_scan_start="));
	    if ( option[0] == '\0' || strcmp(option, "default") == 0 ) // use default value
		system_option[option_index] = 0;
	    else
		system_option[option_index] = atoi(option);

	    break;

      case  HORIZONTAL_SHIFT_PIXEL :
	    strcpy(option, option_string+3+strlen("horizontal_shift_pixel="));
	    if ( option[0] == '\0' || strcmp(option, "default") == 0 ) // use default value
		system_option[option_index] = 0;
	    else
		system_option[option_index] = atoi(option);

	    break;

      case  SCAN_MODE :
	    strcpy(option, option_string+3+strlen("scan_mode="));
	    if ( option[0] == '\0' || strcmp(option, "default") == 0 ) // use default value
		system_option[option_index] = OVERSCAN_MODE;
	    else
		system_option[option_index] = atoi(option);

	    break;

      default :
	    break;

    } // switch( option_index )

  return(TRUE);
} // end function set_option()

// **************************************************************************
//  hex_string_to_int() : convert a hex string to integer
// **************************************************************************
UINT  hex_string_to_int(char *hex_str)
{
    int   i;
    UINT  result, digit;

  result = 0;
  for(i=0; i<strlen(hex_str); i++)
    {
      // convert a hex digit to integer
      switch(hex_str[i])
	{
	  case '0' :
	  case '1' :
	  case '2' :
	  case '3' :
	  case '4' :
	  case '5' :
	  case '6' :
	  case '7' :
	  case '8' :
	  case '9' : digit = hex_str[i] - '0';
		     break;

	  case 'a' :
	  case 'A' : digit = 0x0a;
		     break;

	  case 'b' :
	  case 'B' : digit = 0x0b;
		     break;

	  case 'c' :
	  case 'C' : digit = 0x0c;
		     break;

	  case 'd' :
	  case 'D' : digit = 0x0d;
		     break;

	  case 'e' :
	  case 'E' : digit = 0x0e;
		     break;

	  case 'f' :
	  case 'F' : digit = 0x0f;
		     break;

	} // switch(hex_str[i])

      result = (result << 4) + digit;
    } // for(i=0; i<strlen(hex_str); i++)

  return(result);
} //  end function hex_string_to_int(char *hex_str)

// **************************************************************************
//  init_io_register() : set I/O address values
// **************************************************************************
int  init_io_register(void)
{
  // initialize addresses of I/O registers
  control_reg		= io_base_address + 0x00; // control reg.
  status_reg		= io_base_address + 0x00; // status reg.
  color_key_reg 	= io_base_address + 0x01; // color key reg.
  card_id_reg		= io_base_address + 0x02; // card ID reg.
  crt_sel_reg		= io_base_address + 0x03; // CRT select reg.

/********************
  crt_data_reg		= io_base_address + 0x04; // CRT data reg.
  ramdac_addr_write_reg = io_base_address + 0x05; // RAMDAC address write reg.
  ramdac_addr_read_reg	= io_base_address + 0x06; // RAMDAC address read reg.
  ramdac_data_reg	= io_base_address + 0x07; // RAMDAC data reg.
  ramdac_input_mask_reg = io_base_address + 0x08; // RAMDAC input mask reg.
*********************/

  crt_data_reg		= io_base_address + 0x08; // CRT data reg.
  ramdac_addr_write_reg = io_base_address + 0x04; // RAMDAC address write reg.
  ramdac_addr_read_reg	= io_base_address + 0x07; // RAMDAC address read reg.
  ramdac_data_reg	= io_base_address + 0x05; // RAMDAC data reg.
  ramdac_input_mask_reg = io_base_address + 0x06; // RAMDAC input mask reg.

  // initialize values of I/O registers
  control_reg_val	    = 0x20;  // 0010 0000 control reg.
  status_reg_val	    = 0x00;  // 0000 0000 status reg.
  color_key_reg_val	    = 0xfc;  // 1111 1100 color key reg.
  card_id_reg_val	    = 0x0e;  // 0000 1110 card ID reg.
  crt_sel_reg_val	    = 0x64;  // 0110 0100 CRT select reg.
  crt_data_reg_val	    = 0x00;  // 0000 0000 CRT data reg.
  ramdac_addr_write_reg_val = 0x00;  // 0000 0000 RAMDAC address write reg.
  ramdac_addr_read_reg_val  = 0x00;  // 0000 0000 RAMDAC address read reg.
  ramdac_input_mask_reg_val = 0xff;  // 0000 0000 RAMDAC input mask reg.
  ramdac_data_reg_val	    = 0L;    // 0000 0000 RAMDAC data reg.

  return(TRUE);
} // end function init_io_register()


// **************************************************************************
// load_font_file() : read a font file and create the character set table
//  return : TRUE  ==>	success
//	     FALSE ==>	error
// **************************************************************************
int  load_font_file(void)
{
    int   i, j;
    FILE  *in_file;
    BYTE  *lpData;
    UINT  temp;

  in_file = fopen("junfont.fnt", "rb");
  if ( in_file == NULL )
    return(FALSE);

  lpData = jun_char_set;
  for(i=0; i<CHAR_NUM; i++)
    for(j=0; j<CHAR_HEIGHT; j++)  {
//      fread(&jun_char_set[i][j], sizeof(UINT), 1, in_file);
      fread(lpData, sizeof(UINT), 1, in_file);
      lpData += sizeof(UINT);
    }

  fclose(in_file);
  return(TRUE);
} // end function load_font_file(void)



// **************************************************************************
//  set_junior_config() : set configuration of OVERLAY JUNIOR
// **************************************************************************
int  set_junior_config(void)
{
  set_card_id(card_id);     // set card ID of OVERLAY JUNIOR
  memory_read_enable(TRUE);
  memory_write_enable(TRUE);
  set_color_key(color_key); // set color key to MAGENTA

  set_vert_scroll_reg(vert_scan_start); // set vertical scroll register
  set_horz_shift_reg(horz_shift_pixel); // set horizontal shift register

  // 10/12/93 Tang added to test interrupt
  enable_vert_sync_interrupt(FALSE);
//  enable_vert_sync_interrupt(TRUE);
  // 10/12/93 Tang added to test interrupt
  set_ramdac_input_mask_reg(ramdac_input_mask_reg_val);

  reset_whole_display_color();		// the whole TV not set to a color

  if ( scan_mode == UNDERSCAN_MODE ) // underscan mode
    set_underscan_mode();
  else
    set_overscan_mode();

  set_screen_border_reg(JUN_GREEN);
//  set_screen_border_reg(color_key);

   /* 12/04/93 Tang added to set bank address */
  set_bank_address1(bank_type, bank_pos) ;
//   if ( ! set_bank_address1(bank_type, bank_pos) )
//      return(FALSE);

  flash_video_memory(color_key);

  video_mode_select(OVERLAY);

  return(TRUE);
} // end function set_junior_config()

long  JUN_ColorentryToRGB(BYTE color_entry)
{
   BYTE	*red_color, *green_color, *blue_color;
   long temp_r=0L, temp_g=0L, temp_b=0L;

   // set the first RAMDAC entry to read
//   set_ramdac_address_read_reg(color_entry);
   // get a RAMDAC entry
//   get_ramdac_data_reg(red_color, green_color, blue_color);
   *red_color = 0x2f;
   *green_color = 0x17;
   *blue_color = 0x34;

   // convert RGB value to a long intrger
   temp_r  = (long)(((*red_color   & 0x3f) << 2) | 0x03);
   temp_g  = (long)(((*green_color & 0x3f) << 2) | 0x03);
   temp_b  = (long)(((*blue_color  & 0x3f) << 2) | 0x03);

   return( (long) ((temp_b << 16) + (temp_g << 8) + temp_r) );

}

int  set_bank_address1(BYTE type, BYTE pos)
{
   int  loc, check_flag=TRUE;

   loc = pos;
   do {
      /* determine the video memory address(the bank address) */
      switch ( type ) {
         case BANK_SIZE_64K :
              video_memory = MK_FP(system_option[0], pos);
              break;
         case BANK_SIZE_16K :
              video_memory = MK_FP(system_option[0], 0x4000*pos);
              break;
         case BANK_SIZE_8K :
              video_memory = MK_FP(system_option[0], 0x2000*pos);
              break;
      }
      //12/24/93 Tang: no need to check at DOS environment
      select_bank_address(type, pos);
      return(TRUE);
      /* check the selected bank address is accessable */
      if ( check_bank_access(type, pos) )
         return(TRUE);
      else {
         loc --;
         if ( loc < 0 )
            check_flag = FALSE;
         else
            break;
      } /* end of else */
   } while ( check_flag );
   // bank access error ! //
   return(FALSE);
}


int  set_bank_address(BYTE type)
{
   int  bank_no, i, j, count;
   UINT bank_base;

   if ( type == BANK_SIZE_8K ) {
      bank_no = 7;
      bank_base = 0xe000;  //default
      count = 8;
   }
   else {  //16K
      bank_no = 3;
      bank_base = 0xc000;  //default
      count = 16;
   }

   /* check the 16k bank is acessable */
   while ( bank_no >= 0 ) {
      select_bank_address(type, bank_no);
      video_memory = MK_FP(system_option[0], bank_base);
      // select a video memory segment
      memory_seg_select(0);
      select_bank_segment(type, 0);

      // fill this segment with pattern 0x55
      for ( i=0; i<count; i++ )
         for ( j=0; j<1024; j++ )
	    video_memory[(i<<10) + j] = 0x55;

      // check if this segment if full of pattern 0x55
      for ( i=0; i<count; i++ )
         for ( j=0; j<1024; j++ )
	    if ( video_memory[(i<<10) + j] != 0x55 )
               goto change_bank;

      // fill this segment with pattern 0xaa
      for ( i=0; i<count; i++ )
         for ( j=0; j<1024; j++ )
	    video_memory[(i<<10) + j] = 0xaa;

      // check if this segment if full of pattern 0xaa
      for ( i=0; i<count; i++ )
         for ( j=0; j<1024; j++ )
	    if ( video_memory[(i<<10) + j] != 0xaa )
               goto change_bank;

      break;

change_bank:
      bank_no --;
      if ( type == BANK_SIZE_8K )
         bank_base -= MEMORY_SIZE_8K;
      else  //16K
         bank_base -= MEMORY_SIZE_16K;
   } /* end of while */

   if ( bank_no < 0 )
      return(FALSE);
   return(TRUE);
}

int  check_bank_access(BYTE type, BYTE pos)
{
   int  i, j, nLines;

   switch ( type ) {
      case BANK_SIZE_64K :
//           video_memory = MK_FP(system_option[0], pos);
           nLines = 64;
           break;
      case BANK_SIZE_16K :
//           video_memory = MK_FP(system_option[0], 0x4000*pos);
           nLines = 16;
           break;
      case BANK_SIZE_8K :
//           video_memory = MK_FP(system_option[0], 0x2000*pos);
           nLines = 8;
           break;
   }
   /* set corresponding bank address from command line arguments */
   select_bank_address(type, pos);

   /* set video mode to video only, so write to memory cannot show at screen */
   video_mode_select(EXTERNAL_VIDEO_ONLY);

   /* select a video memory segment 0 and a bank segment 0 to test */
   memory_seg_select(0);
   select_bank_segment(type, 0);

   // fill this segment with pattern 0x55
   for ( i=0; i<nLines; i++ )
      for ( j=0; j<1024; j++ )
	 video_memory[(i<<10) + j] = 0x55;

   // check if this segment if full of pattern 0x55
   for ( i=0; i<nLines; i++ )
      for ( j=0; j<1024; j++ )
	 if ( video_memory[(i<<10) + j] != 0x55 )
            return(FALSE);

   // fill this segment with pattern 0xaa
   for ( i=0; i<nLines; i++ )
      for ( j=0; j<1024; j++ )
	 video_memory[(i<<10) + j] = 0xaa;

   // check if this segment if full of pattern 0xaa
   for ( i=0; i<nLines; i++ )
      for ( j=0; j<1024; j++ )
	 if ( video_memory[(i<<10) + j] != 0xaa )
            return(FALSE);

   return(TRUE);
}



