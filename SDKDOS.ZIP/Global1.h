
// **************************************************************************
// Project : junior.prj
// File    : global.c
// Object  : definitions of global variables
// Author  : Ricky Hsu
// Date    : 820810
// **************************************************************************

//#ifdef VGA_DISPLAY
//  #include  <graphics.h>
//#endif

// ---------------------------------------------------------------------------
//                       system related parameters
// ---------------------------------------------------------------------------
BYTE far  *video_memory;         // segment address of memory space(64K)
UINT      io_base_address,       // base address of I/O registers
          card_id=0,             // card ID of Junior
          irq_line=3,            // hardware interrupt line(IRQ)
          color_key=MAGENTA,     // RAMDAC entry of color key
          horz_disp_start_u=8,   // horizontal display start(underscan)
          horz_disp_stop_u=48,   // horizontal display stop(underscan)
          horz_disp_start_o=5,   // horizontal display start(underscan)
          horz_disp_stop_o=55,   // horizontal display stop(underscan)
          vert_scan_start=0,     // vertical scan start(vertical scroll)
          horz_shift_pixel=0,    // horizontal shift pixel number
          scan_mode=0;           // 0 : underscan, 1 : overscan

BYTE      palette_table[256][3]  // color values of RAMDAC
          = { //         R   G   B     R   G   B     R   G   B     R   G   B
              /*   0 */  0,  0,  0,    0,  0, 42,    0, 42,  0,    0, 42, 42,
              /*   4 */ 42,  0,  0,   42,  0, 42,   42, 21,  0,   42, 42, 42,
              /*   8 */ 21, 21, 21,   21, 21, 63,   21, 63, 21,   21, 63, 63,
              /*  12 */ 63, 21, 21,   63, 21, 63,   63, 63, 21,   63, 63, 63,
              /*  16 */  0,  0,  0,    5,  5,  5,    8,  8,  8,   11, 11, 11,
              /*  20 */ 14, 14, 14,   17, 17, 17,   20, 20, 20,   24, 24, 24,
              /*  24 */ 28, 28, 28,   32, 32, 32,   36, 36, 36,   40, 40, 40,
              /*  28 */ 45, 45, 45,   50, 50, 50,   56, 56, 56,   63, 63, 63,
              /*  32 */  0,  0, 63,   16,  0, 63,   31,  0, 63,   47,  0, 63,
              /*  36 */ 63,  0, 63,   63,  0, 47,   63,  0, 31,   63,  0, 16,
              /*  40 */ 63,  0,  0,   63, 16,  0,   63, 31,  0,   63, 47,  0,
              /*  44 */ 63, 63,  0,   47, 63,  0,   31, 63,  0,   16, 63,  0,
              /*  48 */  0, 63,  0,    0, 63, 16,    0, 63, 31,    0, 63, 47,
              /*  52 */  0, 63, 63,    0, 47, 63,    0, 31, 63,    0, 16, 63,
              /*  56 */ 31, 31, 63,   39, 31, 63,   47, 31, 63,   55, 31, 63,
              /*  60 */ 63, 31, 63,   63, 31, 55,   63, 31, 47,   63, 31, 39,
              /*  64 */ 63, 31, 31,   63, 39, 31,   63, 47, 31,   63, 55, 31,
              /*  68 */ 63, 63, 31,   55, 63, 31,   47, 63, 31,   39, 63, 31,
              /*  72 */ 31, 63, 31,   31, 63, 39,   31, 63, 47,   31, 63, 55,
              /*  76 */ 31, 63, 63,   31, 55, 63,   31, 47, 63,   31, 39, 63,
              /*  80 */ 45, 45, 63,   49, 45, 63,   54, 45, 63,   58, 45, 63,
              /*  84 */ 63, 45, 63,   63, 45, 58,   63, 45, 54,   63, 45, 49,
              /*  88 */ 63, 45, 45,   63, 49, 45,   63, 54, 45,   63, 58, 45,
              /*  92 */ 63, 63, 45,   58, 63, 45,   54, 63, 45,   49, 63, 45,
              /*  96 */ 45, 63, 45,   45, 63, 49,   45, 63, 54,   45, 63, 58,
              /* 100 */ 45, 63, 63,   45, 58, 63,   45, 54, 63,   45, 49, 63,
              /* 104 */  0,  0, 28,    7,  0, 28,   14,  0, 28,   21,  0, 28,
              /* 108 */ 28,  0, 28,   28,  0, 21,   28,  0, 14,   28,  0,  7,
              /* 112 */ 28,  0,  0,   28,  7,  0,   28, 14,  0,   28, 21,  0,
              /* 116 */ 28, 28,  0,   21, 28,  0,   14, 28,  0,    7, 28,  0,
              /* 120 */  0, 28,  0,    0, 28,  7,    0, 28, 14,    0, 28, 21,
              /* 124 */  0, 28, 28,    0, 21, 28,    0, 14, 28,    0,  7, 28,
              /* 128 */ 14, 14, 28,   17, 14, 28,   21, 14, 28,   24, 14, 28,
              /* 132 */ 28, 14, 28,   28, 14, 24,   28, 14, 21,   28, 14, 17,
              /* 136 */ 28, 14, 14,   28, 17, 14,   28, 21, 14,   28, 24, 14,
              /* 140 */ 28, 28, 14,   24, 28, 14,   21, 28, 14,   17, 28, 14,
              /* 144 */ 14, 28, 14,   14, 28, 17,   14, 28, 21,   14, 28, 24,
              /* 148 */ 14, 28, 28,   14, 24, 28,   14, 21, 28,   14, 17, 28,
              /* 152 */ 20, 20, 28,   22, 20, 28,   24, 20, 28,   26, 20, 28,
              /* 156 */ 28, 20, 28,   28, 20, 26,   28, 20, 24,   28, 20, 22,
              /* 160 */ 28, 20, 20,   28, 22, 20,   28, 24, 20,   28, 26, 20,
              /* 164 */ 28, 28, 20,   26, 28, 20,   24, 28, 20,   22, 28, 20,
              /* 168 */ 20, 28, 20,   20, 28, 22,   20, 28, 24,   20, 28, 26,
              /* 172 */ 20, 28, 28,   20, 26, 28,   20, 24, 28,   20, 22, 28,
              /* 176 */  0,  0, 16,    4,  0, 16,    8,  0, 16,   12,  0, 16,
              /* 180 */ 16,  0, 16,   16,  0, 12,   16,  0,  8,   16,  0,  4,
              /* 184 */ 16,  0,  0,   16,  4,  0,   16,  8,  0,   16, 12,  0,
              /* 188 */ 16, 16,  0,   12, 16,  0,    8, 16,  0,    4, 16,  0,
              /* 192 */  0, 16,  0,    0, 16,  4,    0, 16,  8,    0, 16, 12,
              /* 196 */  0, 16, 16,    0, 12, 16,    0,  8, 16,    0,  4, 16,
              /* 200 */  8,  8, 16,   10,  8, 16,   12,  8, 16,   14,  8, 16,
              /* 204 */ 16,  8, 16,   16,  8, 14,   16,  8, 12,   16,  8, 10,
              /* 208 */ 16,  8,  8,   16, 10,  8,   16, 12,  8,   16, 14,  8,
              /* 212 */ 16, 16,  8,   14, 16,  8,   12, 16,  8,   10, 16,  8,
              /* 216 */  8, 16,  8,    8, 16, 10,    8, 16, 12,    8, 16, 14,
              /* 220 */  8, 16, 16,    8, 14, 16,    8, 12, 16,    8, 10, 16,
              /* 224 */ 11, 11, 16,   12, 11, 16,   13, 11, 16,   15, 11, 16,
              /* 228 */ 16, 11, 16,   16, 11, 15,   16, 11, 13,   16, 11, 12,
              /* 232 */ 16, 11, 11,   16, 12, 11,   16, 13, 11,   16, 15, 11,
              /* 236 */ 16, 16, 11,   15, 16, 11,   13, 16, 11,   12, 16, 11,
              /* 240 */ 11, 16, 11,   11, 16, 12,   11, 16, 13,   11, 16, 15,
              /* 244 */ 11, 16, 16,   11, 15, 16,   11, 13, 16,   11, 12, 16,
              /* 248 */  0,  0,  0,    0,  0,  0,    0,  0,  0,    0,  0,  0,
              /* 252 */  0,  0,  0,    0,  0,  0,    0,  0,  0,    0,  0,  0
            };
UINT  jun_char_set[CHAR_NUM][CHAR_HEIGHT]={0}, // character set table
      mask[16] = {
                     0x8000, 0x4000, 0x2000, 0x1000,
                     0x0800, 0x0400, 0x0200, 0x0100,
                     0x0080, 0x0040, 0x0020, 0x0010,
                     0x0008, 0x0004, 0x0002, 0x0001
                 };

UINT      system_option[OPT_NUM];// system option table

// ---------------------------------------------------------------------------
//                addresses of I/O registers of Overlay Junior
// ---------------------------------------------------------------------------
UINT      control_reg,           // 2X0 : control register
          status_reg,            // 2X0 : status register
          color_key_reg,         // 2X1 : color key register
          card_id_reg,           // 2X2 : card ID register
          crt_sel_reg,           // 2X3 : CRT select register
          crt_data_reg,          // 2X4 : CRT data register
          ramdac_addr_write_reg, // 2X5 : RAMDAC address write register
          ramdac_addr_read_reg,  // 2X6 : RAMDAC address read register
          ramdac_data_reg,       // 2X7 : RAMDAC data register
          ramdac_input_mask_reg; // 2X8 : RAMDAC input mask register

// ---------------------------------------------------------------------------
//                 values of I/O registers of Overlay Junior
// ---------------------------------------------------------------------------
BYTE      control_reg_val,           // value of control register
          status_reg_val,            // value of status register
          color_key_reg_val,         // value of color key register
          card_id_reg_val,           // value of card ID register
          crt_sel_reg_val,           // value of CRT select register
          crt_data_reg_val,          // value of CRT data register
          ramdac_addr_write_reg_val, // value of RAMDAC address write register
          ramdac_addr_read_reg_val,  // value of RAMDAC address read register
          ramdac_input_mask_reg_val; // value of RAMDAC input mask register
ULONG     ramdac_data_reg_val;       // value of RAMDAC data register

unsigned long   enter_interrupt=0;

int  ynouse, yheight, sstart, fScroll;

/* 12/04/93 Tang added */
int  bank_type, bank_pos;
