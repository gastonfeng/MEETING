#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <dos.h>
#include <conio.h>
#include <string.h>
#include <ctype.h>
#include <bios.h>
#include <sys\stat.h>
#include "junior2.h"
#include "global1.h"

/****************************************************************************
* Text attribute(8 bits):
*     7 6 5 4  3 2 1 0
*     B b b b  f f f f
*
* B : Blink enable bit,
* b : 3 bits background color (0-7)
* f : 4 bits forground color (0-15)
****************************************************************************/
int  attribute = 0x07;
int  invattr = 0x70;
int  msg_attr = 0x07;
int  val_attr = 0x07;
int  item_no = 0;
int  pattern_rw = 0;
int  pickornot[9]={0};
int  teststatus[9]={0};
int  repeatime[2] = {1};
int  nItemsMain = 3;
int  nItemsUser = 9;
int  nTestType = 0;   // 0:Default, 1:Customer, 2:Exit
int  fSuccess = 0;
int  fTestDone = 0;
int  fQuit;
int  xStart, xEnd, yStart, yEnd, yNow, xShow = 0;

char *sMainItemText[3] = {
	" Default  Test  ",    //width:16
	" Customer Test  ",
	" Exit           ",
 } ;

char *sUserItemText[9] = {
	" 1. Junior Card Exist    ",  //width:25
	" 2. External Video Exist ",
        " 3. Vsync Interrupt      ",
        " 4. Flash Video memory   ",
	" 5. Video Memory R/W     ",
	" 6. Video Mode Switch    ",
	" 7. RAMDAC R/W           ",
	" 8. Vertical Scroll      ",
	" 9. Horizontal Shift     ",
//      "Display Start/End Adjust ",
} ;

int (*fnMainFunc[3])() = {
	DefaultTest,
	CustomerTest,
	ExitProgram,
} ;
 
int (*fnUserFunc[9])() = {
	CheckCardExist,
	CheckVideoExist,
        VsyncInterrupt,
        FlashMemory,
	VideoMemoryRW,
	VideoModeSwitch,
	RamdacRW,
	VerticalScroll,
	HorizontalShift,
//	DisplayAdjust,
} ;

char *sMainItemMsg[] = {
	"Use default items to test JUNIOR.           ", //58
	"Choose desired items to test JUNIOR.        ",
	"Exit test program.                          ",
} ;


char *sUserItemMsg[] = {
	"Check the OVERLAY JUNIOR card exist or not. ",
	"Detect external video exist or not.         ",
        "Detect vertical sync interrupt.             ",
        "Test flash video memory operation.          ",
	"Test video memory Read/Write operation.     ",
	"Test video mode switch operation.           ",
	"Color Ramdac Read/Write test.               ",
	"Vertical scroll up/down the screen.         ",
	"Horizontal shift left/right the screen.     ",
//	"Adjust display start/end position.                    ",
} ;

//1/21 Tang added
void SetVideoMode(BYTE mode_no);
//1/27/94 Tang added to distinguish various vga mode for display video
int vga_mode;


/*--------------------------  Main program  ------------------------------*/

void main(int  argc, char *argv[])
{
   int  i;
   int  imr_value, irr_value, isr_value;

   /* 12/04/93 Tang added to accept user input bank selection */
   bank_type = BANK_SIZE_16K;
   bank_pos = 0;
   if ( argc > 1 ) {  // has command line arguments
      bank_type = (BYTE) atoi(argv[1]);
      if ( ! ( bank_type <= 2 && bank_type >= 0 ) ) {
         printf("argument 1 must be from 0 to 2 \n");
         exit(1);
      }
      if ( bank_type > 0 ) {
         bank_pos  = (BYTE) atoi(argv[2]);
         if ( ! ( bank_pos <= 7 && bank_pos >= 0 ) ) {
            printf("argument 2 must be from 0 to 7 \n");
            exit(1);
         }
      }
   }
   /* 12/04/93 Tang added to accept user input bank selection */

   disable();
  // read IMR
  imr_value = inportb(0x21);

  // read IRR
  outportb(0x20, 0x0a);
  irr_value = inportb(0x20);

  // read ISR
  outportb(0x20, 0x0b);
  isr_value = inportb(0x20);

  enable();
   // load font file "junfont.fnt"
   if ( load_font_file() == FALSE )  {  // font file trouble
      printf("Error : Font file not available !\n");
      exit(1);
   }

   // read "junior.ini" file to set system options
   set_system_option();

   // initialize I/O registers
   init_io_register();

   // set configuration of OVERLAY JUNIOR
   set_junior_config();

   // initialize RAMDAC entries
   init_ramdac_entry();

   // 10/12/93 Tang added to setup interrupt
   init_interrupt();

   for (i=0; i<nItemsMain-1; i++)
      repeatime[i]=1;
   for (i=0; i<1; i++)
      pickornot[i]=1;     //must to test card exist!
   for (i=1; i<nItemsUser; i++)
      pickornot[i]=0;     //Initialize every item to be unpicked

   SetupMainScreen();
   PopupMainMenu();
   // initialize test-result area for prompting result message
   InitialResultArea();
   ShowStatus();

   SelectTest();      //Loop for selecting Test(D/C) and running Test
}

void SetupMainScreen(void)
{
   int i, j, titleattr;
   char *sTitleLine = "   OVERLAY JUNIOR Test Program     Version 2.0   ";

   attribute = (( BLUE << 4 ) | LIGHTCYAN);
   textattr( 0x07 );	//Default Text attribute to B/W
   clrscr();
   vga_mode = GetVideoMode();
   if ( vga_mode != MONO ) {    //Color Text mode 3
      // 1/27/94 Tang updated
      if ( vga_mode == C80 ) {
         textmode( C80 );    //Change screen mode
         /* Menu's attribute, background:BLUE, text:LIGHTCYAN */
         attribute = (( BLUE << 4 ) | LIGHTCYAN);
         /* Invert menu's attribute(choosed), background:CYAN, text:BLACK */
         invattr = (( CYAN << 4 ) | BLACK);
         /* Message's attribute, background:BLACK, text:LIGHTCYAN */
         msg_attr = (( BLACK << 4 ) | LIGHTCYAN);
         /* Valuable text's attribute, background:BLACK, text:YELLOW */
         val_attr = (( BLUE << 4 ) | YELLOW);
         //Set Title line's attribute, background:BLACK, text:YELLOW
         titleattr = ((BLACK<<4) | YELLOW);
      }
      else {    // assume mode 0x12
//         SetVideoMode(0x12);
         attribute  = (( BLACK << 4 ) | WHITE);
         invattr = (( CYAN << 4 ) | LIGHTGREEN);
         msg_attr = (( BLACK << 4 ) | LIGHTCYAN);
         val_attr = (( BLUE << 4 ) | YELLOW);
         titleattr = ((BLACK<<4) | YELLOW);
      }
   }
   else {
      textmode( BW80 );               //Monochrome text mode 7
      /*	asm mov ax, 7;
      asm int 10h;   */
      attribute = 0x07;
      invattr = 0x70;
      msg_attr = 0x07;
      titleattr = 0x07;
   }
//   close_scr();
   if ( attribute != 7 )
      textattr( titleattr );
   window( 1, 1, 80, 25 );
   /* show title string */
   gotoxy(2,2);
   cprintf(sTitleLine);
   DrawBorder( 1, 1, strlen(sTitleLine)+2, 3, 1, titleattr );

   /* show card type */
     gotoxy( 63, 2 );
     if ( attribute != 7 )
        textattr( ( BLACK << 4 ) | WHITE );
     else
        textattr( 0x07 );
     cprintf("Card type : ");
     if ( attribute != 7 )
        textattr( ( BLACK << 4 ) | WHITE );
     else
        textattr( 0x70 );
     if ( junior_exist() )
        if ( TV_system_type() == NTSC )
           cprintf("NTSC");
        else cprintf("PAL");
     else
        cprintf("None");

//   if ( attribute != 7 )
//      textattr( ( BLUE << 4 ) | WHITE ) ;
//      textattr( ( BLACK << 4 ) | WHITE ) ;
//   for ( i = 0; i < 16; i ++ )
//      for ( j = 0; j < 80; j ++ )
//         putch( ' ' );
//	 putch( '�' );
   if ( attribute != 7 )
      textattr( ( BLACK << 4 ) | WHITE ) ;
   else
      textattr( 0x07 ) ;
   gotoxy(1,21);
   cprintf("control keys:  select:ENTER,  go:G,  pause:SPACE,  continue:C,  abort:ESC");
   gotoxy(1,22);
   cprintf( "��� Message �����������������������������������������������������������������Ŀ\n\r" );
   cprintf( "� Use default items to test                                                   �\n\r" );
   cprintf( "� Date :  Fri Oct 02, 1993                                  Time : 23:59:59   �\n\r" );
   cprintf( "�������������������������������������������������������������������������������" );
   //Restore original menu attribute
   textattr( attribute );
   ShowDate();
//	open_scr();
}

void PopupMainMenu(void)
{
   int i;
   POINT pPnt;

   window( 1, 5, 27, 10 );	  /* define active text-mode  window */
   /*                �> no. of iyem plus 1, for cprintf's return use */
//   DrawBorder( 1, 1, 27, 5, 1, attribute );  /* relative to active window */
//*   textattr( attribute );
//   for ( i = 0; i < nItemsMain; i ++ ) {
//      gotoxy( 2, i+2 );      /* relative to active text window */
//      cprintf( "%s", sMainItemText[i], "          " );
//   }
   gotoxy( 1, 1 );
   //        1                 19
   cprintf( "������������������ repeat �" ) ;  //line 5
   cprintf( "� Default  Test           �" ) ;  //line
   cprintf( "� Customer Test           �" ) ;
   cprintf( "� Exit                    �" ) ;
   cprintf( "�������������������������ͼ" ) ;
   for (nTestType=0; nTestType<nItemsMain-1; nTestType++)
      UpdateRepeatTime();
   window(1, 5, 27, 10);
   InvertText( 2, 2, sMainItemText[0] , invattr );
   textattr( attribute );
   window( 2, 10, 42, 21 );
   gotoxy( 1, 1 );
   //        2  5  8  11                     34 37   42
   cprintf( "�� c ��� Items ������������������� QC �Ŀ" ) ;  //line 10
   cprintf( "� [ ]   1. Junior Card Exist            �" ) ;  //line 11
   cprintf( "� [ ]   2. External Video Exist         �" ) ;
   cprintf( "� [ ]   3. Vsync Interrupt              �" ) ;
   cprintf( "� [ ]   4. Flash Video memory           �" ) ;
   cprintf( "� [ ]   5. Video Memory R/W             �" ) ;
   cprintf( "� [ ]   6. Video Mode Switch            �" ) ;
   cprintf( "� [ ]   7. RAMDAC R/W                   �" ) ;
   cprintf( "� [ ]   8. Vertical Scroll              �" ) ;
   cprintf( "� [ ]   9. Horizontal Shift             �" ) ;
   cprintf( "�����������������������������������������" ) ;  //lline20
//      "Display Start/End Adjust ",
   window(1, 1, 80, 25);
   pPnt.x = 5;
   pPnt.y = 11;
   for (i=0; i<nItemsUser; i++) {
      UpdateCheckBox(i, pPnt.x, pPnt.y);
      pPnt.y += 1;
   }
   window( 44, 5, 78, 22 );
   gotoxy( 1, 1 );
   //       44 46                              78
   cprintf( "�� Test Result ������������������Ŀ" ) ; //line 5
   cprintf( "�                                 �" ) ; //line 6
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ; //width:33
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;
   cprintf( "�                                 �" ) ;  //line 19
   cprintf( "�����������������������������������" ) ;  //line 20
//      "Display Start/End Adjust ",
   window( 1, 1, 80, 25 );
}


void SelectTest(void)
{
   int  xLeft, yTop;

   xLeft = 2;   //start to show text string
   yTop = 6;
   nTestType = 0;
   for ( ; ; ) {
      // 10/12/93 Tang added
      fQuit = FALSE;
      pattern_rw = 0;
      nTestType = GetMenuSelect( xLeft, yTop, nItemsMain, sMainItemText, "dce",
                                 nTestType, sMainItemMsg);
      if ( nTestType == -1 ) {     //ESC
	 nTestType = 2;            //goto Exit
	 InvertText( xLeft, yTop+nTestType, sMainItemText[nTestType], invattr );
      }
      ActiveFunc( nTestType );
   }  /* end of for loop */
}


/****************************************************************************
* GetRepeatTime(void)
*
*   This routine get the repeat time for test.
*
* Entry: None
****************************************************************************/
void GetRepeatTime(void)
{
   char *szBuffer, rstring[12];
   char *szMsg = { "Input repeat times(0=�): " };
   int i, j, len_str;
   int tempattr=0x07, invdisp=0x07 ;

   if ( (szBuffer = (char *)malloc( 344 )) == NULL ) {
      MessageOut(xShow, "Not enough memory!");
      exit(1);
   }
      if ( attribute != 7 ) {
         invdisp = attribute;
	 tempattr = val_attr;
//         attribute = ( BLUE << 4 ) | YELLOW;
      }
      //create a specifed window area and store text in this area to buffer
      SetupWindow( 3, 9, 44, 11, szBuffer, NULL, tempattr );
      gotoxy( 8, 10 );
      cprintf( szMsg );
      do {
         repeatime[nTestType] = get_dec_int( 8+strlen(szMsg)+2, 10, 5,
                                          repeatime[nTestType] );
      } while (! (repeatime[nTestType]>=0 && repeatime[nTestType]<=32767) );
//      attribute = invdisp;
      //restore original screnn state
      puttext( 3, 9, 44, 11, szBuffer );  //copy text from memory to screen
      free( szBuffer );
      UpdateRepeatTime();

}

/****************************************************************************
* Activefun(nSelect)
*
*   This routine execute function(operation) which user select
*
* Entry: select - select no return by menu select
****************************************************************************/
void ActiveFunc(int nSelect)
{
   window( 1, 1, 80, 25 );
   DrawBorder( 1, 5, 27, 5, 0, attribute );     //Nonactive main menu
   gotoxy( 19, 5 );
   puts( " repeat " );
   /* Call selected main menu item's function */
   (*(fnMainFunc[nSelect]))();

   window ( 1, 1, 80, 25 );
   DrawBorder( 1, 5, 27, 5, 1, attribute );     //Active main menu
   gotoxy( 19, 5 );
   puts( " repeat " );
   textattr(attribute);
}


int DefaultTest(void)
{
   int  i;
   POINT pPnt;
   char *sTestOrNot = { "Do you want to test JUNIOR card ?" };
   char *sTestFail = { "Junior test failed ! Try to Correct it." };
   char *sTestSuccess = { "Congratulation ! Junior test succeeded." };

   GetRepeatTime();
//   window(1, 1, 80, 25);
   pPnt.x = 5;
   pPnt.y = 11;
   for (i=0; i<nItemsUser; i++) {
      pickornot[i]=1;
      UpdateCheckBox(i, pPnt.x, pPnt.y);
      pPnt.y += 1;
   }
   if ( AskUser(sTestOrNot) == YES ) {     //do test
      do {
         for (i=0; i<nItemsUser; i++)
            teststatus[i]=1;     //Initialize every item to be return true
      	 fTestDone = FALSE;
         fSuccess = RunTest();
         thinborder(2);
         if ( fQuit ) {   //User break
            MessageOut(xShow, "User break!");
            fSuccess = FALSE;
         }
         else
            for ( i=0; i<nItemsUser; i++ )
               if ( pickornot[i] && (!teststatus[i]) ) {
                  ShowResultMsg(sTestFail);
                  fSuccess = FALSE;   //fail or user break
                  break;
               }
      	 if ( (fSuccess) && (repeatime[nTestType] == 1) )
            ShowResultMsg(sTestSuccess);
      	 fTestDone = TRUE;    //one test is over
      	 UpdateQC(0);
      	 ClearResultArea();
         if ( ! fSuccess )
            return(FALSE);
         else {
      	    if ( repeatime[nTestType] == 1 )  break;
      	    else if (repeatime[nTestType]!=0) repeatime[nTestType] -= 1 ;
      	    UpdateRepeatTime();
         }
      } while ( repeatime[nTestType] >= 0 );    /* end of for loop */
   } /* end of if (AskUser) */
   return(TRUE);
}

int CustomerTest(void)
{
   int  i, select=1, count=0;
   POINT pPnt;
   char *sTestOrNot   = { "Do you want to test JUNIOR card ?" };
   char *sTestFail    = { "Junior test failed ! Try to Correct it." };
   char *sTestSuccess = { "Congratulation ! Junior test succeeded." };
   char *sPickOne     = { "Select at least one item to test, O.K ?" };

   GetRepeatTime();
   thickborder(1);    //active Customer window
   pPnt.x = 5;
   pPnt.y = 11;
   for (i=0; i<nItemsUser; i++) {
      UpdateCheckBox(i, pPnt.x, pPnt.y);
      pPnt.y += 1;
   }
//   for (i=0; i<nItemsUser; i++) {
//      gotoxy( 5, 11+i);
//      if (pickornot[i])
//         putch('X');
//      else putch(' ');
//   }

   for ( ; ; ) {
      select = GetMenuSelect(9, 11, nItemsUser, sUserItemText, NULL,
                             select, sUserItemMsg);
      item_no = select;
      if ( select == nItemsUser ) {    //G, g -> Go
         thinborder(1);       //nonactive Custom window
         for (i=0; i<nItemsUser; i++) {
            if ( pickornot[i] )
	    count ++;
         }
         if ( count == 0 )
            ShowResultMsg(sPickOne);
         else
	    break;
      }
      else if ( select == -1 ) {   //ESC
              thinborder(1);       //nonactive Custom window
              return(TRUE);
           }

      if ( select != -1 )
	 (*( fnUserFunc[select] )) ();
      else
	  select = 1;
   } /* end of For-loop */
   if ( AskUser(sTestOrNot) == YES ) {
      do {
         for (i=0; i<nItemsUser; i++)
            teststatus[i]=1;     //Initialize every item to be return true
      	 fTestDone = FALSE;
         fSuccess = RunTest();
         thinborder(2);
         if ( fQuit ) {
            MessageOut(xShow, "User break!");
            fSuccess = FALSE;
         }
         else
            for ( i=0; i<nItemsUser; i++ )
               if ( pickornot[i] && (!teststatus[i]) ) {
                  ShowResultMsg(sTestFail);
                  fSuccess = FALSE;   //fail or user break
                  break;
               }
      	 if ( (fSuccess) && (repeatime[nTestType] == 1) )
            ShowResultMsg(sTestSuccess);
      	 fTestDone = TRUE;
      	 UpdateQC(0);
      	 ClearResultArea();
         if ( ! fSuccess ) {
            thinborder(1);    //nonactive Custom window
            return(FALSE);
         }
         else {
      	    if ( repeatime[nTestType] == 1 )  break;
      	    else if (repeatime[nTestType]!=0) repeatime[nTestType] -= 1 ;
      	    UpdateRepeatTime();
         }
      } while ( repeatime[nTestType] >= 0 );    /* end of for loop */
   } /* end of if (AskUser==Yes) */

   thinborder(1);     //nonactive Custom window

   // 10/07 Tang added
   return(TRUE);
}

void thickborder(int nArea)
{
   if ( nArea == 1 ) {      //active Customer select area
      window(1, 1, 80, 25);
      DrawBorder( 2, 10, 41, 11 , 1 , attribute );
      gotoxy( 8, 10 );
      putch( '�' );
      gotoxy( 34, 10 );
      putch( '�' );
      gotoxy( 8, 20 );
      putch( '�' );
      gotoxy( 34, 20 );
      putch( '�' );
      gotoxy( 5, 10 );
      puts(" c " );
      gotoxy( 11, 10 );
      puts(" Items " );
      gotoxy( 37, 10 );
      puts(" QC " );
   }
   else {                     //active Test Result area
      window(1, 1, 80, 25);
      DrawBorder( 44, 5, 35, 16, 1, attribute );
      gotoxy( 46, 5 );
      puts(" Test Result " );
   }
}

void thinborder(int nArea)
{
   if ( nArea == 1 ) {      //nonactive Customer select area
      window(1, 1, 80, 25);
      DrawBorder( 2, 10, 41, 11 , 0 , attribute );
      gotoxy( 8, 10 );
      putch( '�' );
      gotoxy( 34, 10 );
      putch( '�' );
      gotoxy( 8, 20 );
      putch( '�' );
      gotoxy( 34, 20 );
      putch( '�' );
      gotoxy( 5, 10 );
      puts(" c " );
      gotoxy( 11, 10 );
      puts(" Item " );
      gotoxy( 37, 10 );
      puts(" QC " );
   }
   else {                     //nonactive Test Result area
      window(1, 1, 80, 25);
      DrawBorder( 44, 5, 35, 16, 0, attribute );
      gotoxy( 46, 5 );
      puts(" Test Result " );
   }
}

int CheckCardExist(void)
{
   POINT pPnt;

   pickornot[item_no] ^= 1;
   pPnt.x = 5;
   pPnt.y = 11+item_no;
   UpdateCheckBox(item_no, pPnt.x, pPnt.y);
   return(TRUE);
}

int CheckVideoExist(void)
{
   POINT pPnt;
   pickornot[item_no] ^= 1;
   pPnt.x = 5;
   pPnt.y = 11+item_no;
   UpdateCheckBox(item_no, pPnt.x, pPnt.y);
   return(TRUE);
}

int VsyncInterrupt(void)
{
   POINT pPnt;

   pickornot[item_no] ^= 1;
   pPnt.x = 5;
   pPnt.y = 11+item_no;
   UpdateCheckBox(item_no, pPnt.x, pPnt.y);
   return(TRUE);
}

int FlashMemory(void)
{
   POINT pPnt;

   pickornot[item_no] ^= 1;
   pPnt.x = 5;
   pPnt.y = 11+item_no;
   UpdateCheckBox(item_no, pPnt.x, pPnt.y);
   return(TRUE);
}

int VideoMemoryRW(void)
{
   char *buffer;
   char *msg = { "Read/Write pattern(XX): " };
   int i, tempattr=0x07, invdisp = 0x07 ;
   POINT pPnt;

   pickornot[item_no] ^= 1;
   if ( pickornot[item_no] ) {
      textattr(val_attr);
      gotoxy( 5, 15);
      putch('X');
      textattr(attribute);

      if ((buffer = (char *)malloc(252)) == NULL ) {
         MessageOut(xShow, "Not enough memory!");
         exit(1);
      }
      if ( attribute != 7 ) {
         invdisp = attribute;
	 tempattr = val_attr;
//         attribute = ( BLUE << 4 ) | YELLOW;
      }
      //create a specifed window area and store text in this area to buffer
      SetupWindow( 3, 17, 44, 19, buffer, NULL, tempattr );
      gotoxy( 8, 18 );
      cprintf( msg );
      do {
         pattern_rw = get_hex_int( 8+strlen(msg)+2, 18, 3, pattern_rw );
      } while (! (pattern_rw>=0 && pattern_rw<=0xff) );
//      attribute = invdisp;
      //restore original screnn state
      puttext( 3, 17, 44, 19, buffer );  //copy text from memory to screen
      free( buffer );
   }
   else {
      pattern_rw = 0;
//      textattr(val_attr);
      gotoxy( 5, 15);
      putch(' ');
      textattr(attribute);
   }
   return(TRUE);
}

int VideoModeSwitch(void)
{
   POINT pPnt;

   pickornot[item_no] ^= 1;
   pPnt.x = 5;
   pPnt.y = 11+item_no;
   UpdateCheckBox(item_no, pPnt.x, pPnt.y);
   return(TRUE);
}

int RamdacRW(void)
{
   POINT pPnt;

   pickornot[item_no] ^= 1;
   pPnt.x = 5;
   pPnt.y = 11+item_no;
   UpdateCheckBox(item_no, pPnt.x, pPnt.y);
   return(TRUE);
}

int VerticalScroll(void)
{
   POINT pPnt;

   pickornot[item_no] ^= 1;
   pPnt.x = 5;
   pPnt.y = 11+item_no;
   UpdateCheckBox(item_no, pPnt.x, pPnt.y);
   return(TRUE);
}

int HorizontalShift(void)
{
   POINT pPnt;

   pickornot[item_no] ^= 1;
   pPnt.x = 5;
   pPnt.y = 11+item_no;
   UpdateCheckBox(item_no, pPnt.x, pPnt.y);
   return(TRUE);
}


int DisplayAdjust(void)
{
   pickornot[item_no] ^= 1;
   if ( pickornot[item_no] ) {
      gotoxy( 5, 20);
      putch('X');
   }
   else {
      gotoxy( 5, 20);
      putch(' ');
   }
   return(TRUE);
}

void UpdateRepeatTime(void)
{
   char rstring[12];
   int  j, len_str;

   window(1, 5, 27, 10);
   textattr(val_attr);
   if ( repeatime[nTestType] == 0 ) {
      strcpy(rstring,"�");
      len_str = 1;
   }
   else {
      itoa(repeatime[nTestType], rstring, 10);
      len_str = strlen(rstring);
   }
   for ( j=0; j<5-len_str; j++) {
      gotoxy( 21+j, 2+nTestType );   //relative to active window
      cprintf(" ");
   }
   for (j=0; j<len_str; j++) {
      gotoxy(21+5-len_str, 2+nTestType);
      cprintf(rstring);
   }
   textattr(attribute);
   window(1, 1, 80, 25);
}

void UpdateCheckBox(int nSel, int x, int y)
{
   gotoxy( x, y);
   if ( pickornot[nSel] ) {
      textattr(val_attr);
      putch('X');
      textattr( attribute );
   }
   else
      putch(' ');
   textattr(attribute);
}

void UpdateQC(int nSel)
{
   int  x, y, i;
   char *sPass = "pass";
   char *sFail = "fail";
   char *sNull = "    ";

//   window(2, 10, 41, 11);
   /* During test process, according to TRUE or FALSE, output "pass" or
      "fail to QC area */
//   textattr(attribute);
   if ( fTestDone == FALSE ) {
      x = 36;
      y = 11+nSel;
      gotoxy( x, y);
      if ( teststatus[nSel] )
      	 puts(sPass);
      else {
        if ( attribute != 7 )
      	   textattr( (WHITE << 4) | RED);
        else
      	   textattr( 0x70 );
      	cprintf(sFail);
//      	puts(sFail);
      }
   }
   /* After one test process is done and want to go next, output "    "
      to QC area for new test process */
   else {
      x = 36;
      for ( i=0; i<nItemsUser; i++ ) {
         if ( pickornot[i] ) {
            y = 11+i;
            gotoxy( x, y);
            cprintf(sNull);
//            puts(sNull);
         }
      }
   }
   textattr(attribute);
//   window(1, 1, 80, 25);
}

void ClearResultArea(void)
{
   int  i;

   textattr(attribute);
   for (i=yStart; i<yNow; i++) {
      gotoxy(xStart, i);
      puts("                               "); //width:33-2=31
   }
   yNow = yStart;
}

int ExitProgram(void)
{
   union {
         int icode;
         char ch[2];
   } keyin;
   char *buffer;
   int tempattr=0x07, invdisp=0x07;

   if ( (buffer = (char *)malloc( 344 )) == NULL ) {
      MessageOut(xShow, "Not enough memory!");
      exit(1);
   }
   if ( attribute != 0x07 ) {
      invdisp = attribute;
      tempattr = (BLUE << 4 ) | YELLOW;
   }
   SetupWindow( 14, 13, 56, 16, buffer, NULL, tempattr );

   gotoxy( 21, 14 );
   cputs( "    Exit test program      " );
   gotoxy( 21, 15 );
   cputs( "Do you want to EXIT ?(Y/N) " );
   gotoxy( 3, 23 );
   textattr( msg_attr );
   cprintf("Press N to return to main menu, or Y to exit           ");
   textattr( attribute );
//   puts("Press N to return to main menu, or Y to exit           ");
   for ( ; ; ) {
      keyin.icode = get_keyin( 48, 15 );
	      switch ( keyin.ch[0] ) {
	 case 'y' :
	 case 'Y' : goto exit1;
	 case 'n' :
	 case 'N' :
	 case ESC :
	 case RET : puttext ( 14, 13, 56, 16, buffer );
	   	    free( buffer );
//		    attribute = invdisp;
		    return(TRUE);
      }
   } /* end of for */

exit1:
   free( buffer );

   // 10/12/93 Tang added to setup interrupt
   restore_interrupt();

   disable_card();

   textattr( ( BLACK << 4 ) | LIGHTGRAY );
   clrscr();
   exit( 0 );
   return(TRUE);
}


void InitialResultArea(void)
{
   int xLeft, yTop, xRight, yBottom;

   xLeft = 44;       // the (left, top) of window
   yTop = 5;
   xRight = 78;      // the (right, bottom) of window
   yBottom = 20;
   xStart = xLeft + 2;      // start of column to show message
   xEnd = xRight - 2;       // end of row to show message
   yStart = yTop + 1;       // start of row to show message
   yEnd =  yBottom - 1;     // end of row to show message
   yNow = yStart;
   xShow = 0;
//   window(xLeft, yTop, xRight, yBottom);
}


void MessageOut(int col, char *resultmsg)
{
   if ( yNow > yEnd ) {
      yNow = yEnd;
     /* copy text on screen from one rectangle to another,
        scroll up one line, delete the top-most line */
      movetext(xStart, yStart+1, xEnd, yEnd, xStart, yStart);
      /* insert a blank in text window at cursor position */
//      insline();
      gotoxy(xStart, yNow);
      puts("                               "); //width:33-2=31
   }
//   textattr(val_attr);
   gotoxy(xStart+col, yNow);
//   puts(resultmsg);
   cprintf(resultmsg);
//   puttext(xStart+col, yNow, xEnd, yNow, resultmsg);
   yNow ++;
   textattr(attribute);
   // 10/13/93 Tang add
   window(1, 1, 80, 25);
}


int  RunTest(void)
{
   int  i;
   char OKmsg[11] = "test O.K !";
   POINT pPnt;
   char *itemmsg[] = {
      	"1. Junior Card Exist...   ",
	"2. External Video Exist...",
        "3. Vsync Interrupt...     ",
        "4. Flash Video memory...  ",
	"5. Video Memory R/W...    ",
	"6. Video Mode Switch...   ",
	"7. RAMDAC R/W...          ",
	"8. Vertical Scroll...     ",
	"9. Horizontal Shift...    ",
   };

//12/24   set_system_option();
   set_junior_config();
   init_ramdac_entry();

   thickborder(2);
   for ( i=0; i<nItemsUser; i++ ) {
      if ( pickornot[i] ) {     //selected item to test
         MessageOut(xShow, itemmsg[i]);   //show topic
         switch ( i ) {
            case 0 : teststatus[i] = test_junior_exist();
      		     if ( ! teststatus[i] ) {
      			UpdateQC(i);
      			return(TRUE);
   		     }
         	     break;
            case 1 : teststatus[i] = test_external_video_exist();
                     break;
            case 2 : teststatus[i] = test_vert_sync_int();
                     break;
	    case 3 : teststatus[i] = test_flash_memory();
                     break;
	    case 4 : teststatus[i] = test_video_memory();
                     break;
	    case 5 : teststatus[i] = test_video_mode();
                     break;
	    case 6 : teststatus[i] = test_ramdac();
                     break;
	    case 7 : teststatus[i] = test_vertical_scroll();
                     break;
	    case 8 : teststatus[i] = test_horz_shift();
                     break;
         }  /* end of switch */
         if ( teststatus[i] )     //test return TRUE
      	    MessageOut(xShow+1, OKmsg);   //show test O.K
         UpdateQC(i);             //update QC to show to user
         if ( fQuit )  return(FALSE);  //user break? Yes,return FALSE.
         ShowStatus();
         WaitForResponse(2);           //wait user to response
         if ( fQuit )  return(FALSE);  //Yes, return. No,escape
      } /* end of pickornot */
   } /* end of for */

   // 11/05/93 Tang added
//   enable_vert_sync_interrupt(FALSE);
   // 11/05/93 Tang added

   return(TRUE);
}

/****************************************************************************
* InvertText(xLeft, yTop, sTextMsg[], nSpcAttr)
*
*   Goto screen (xLeft, yTop) and show text with special attribute(the
* location of light bar.
*
* Entry: (xLeft,yTop) - screen coord. which accepted user to keyin
*        act -
* Return: ASCII code or scan code if lower 8 bits is 0
****************************************************************************/
void InvertText(int xLeft, int yTop, char sTextMsg[], int nSpcAttr)
{
   gotoxy( xLeft , yTop );
   textattr( nSpcAttr );
   cprintf("%s", sTextMsg );
   textattr( attribute );
}

/***************************************************************************
* DrawBorder(xLeft, yTop, xRight, yHeight, nLineStyle, nSpcAttr)
*
*   This routine draw "typed" border for a specified window which defined by
* (left, top) and (right, bottom).
*
* Entry:  (xLeft, yTop) - left top coord. relative to active window
*	  xRight - right coord. relative to active window
*         yHeight - Height of rectangle
*	  type: 0 -- single line : ���Ŀ
*		1 -- double line : ���ͻ
*	  attr : text(line here)'s mono./color attribute
**************************************************************************/
void DrawBorder(int xLeft, int yTop, int xRight, int yHeight,
		int nLineStyle, int nSpcAttr)
{
   int i;

   textattr( nSpcAttr );
   gotoxy( xLeft, yTop++ );
   cprintf("%c", ( !nLineStyle ) ? 218 : 201 );     //ASCII 218=�, 201=�
   for ( i = 0; i < xRight - 2; i ++ )
      cprintf("%c", ( !nLineStyle ) ? 196 : 205 );  //ASCII 196=�, 205=�
   cprintf("%c", ( !nLineStyle ) ? 191 : 187 );     //ASCII 191=�, 187=�
   for ( i = 0; i < yHeight - 2; i ++ ) {
      gotoxy( xLeft, yTop );
      cprintf("%c", ( !nLineStyle ) ? 179 : 186 );  //ASCII 179=�, 186=�
      gotoxy( xLeft+xRight-1, yTop++ );
      cprintf("%c", ( !nLineStyle ) ? 179 : 186 );
   }
   gotoxy( xLeft, yTop );
   cprintf("%c", ( !nLineStyle ) ? 192 : 200 );     //ASCII 192=�, 200=�
   for ( i = 0; i < xRight - 2; i ++ )
      cprintf("%c", ( !nLineStyle ) ? 196 : 205 );
   cprintf("%c", ( !nLineStyle ) ? 217 : 188 );     //ASCII 217=�, 188=�
}

int  get_keyin(int x, int y)
{
   gotoxy( x, y );
   while ( !bioskey( 1 ) ) {   //1-If keystroke is available?  No,
//      gotoxy( x, y );
//      if ( act == 0 )
	 ShowTime();           //Update time showed at screen
   }
   return( bioskey( 0 ) );     //Read
}

/**************************************************************************
* Return: TRUE - nothing happen
*         FALSE - user break
**************************************************************************/
int  WaitForResponse(int interval)     //interval : time in seconds
{
   int  esckey;
   time_t  first, second;
   char *sAbortOrNot = { "Do you want to abort testing ?" };

   first = time(NULL);  /* Gets system time */
   delay(10);           /* wait 1/100 second = 10 milliseconds */
   second = time(NULL); /* Gets system time again */
   for ( ; ; ) {
      while ( !bioskey(1) ) {   //1-If keystroke is available?  No,
         if ( difftime(second,first) < interval ) { //wait for elapse seconds
            ShowTime();           //Update time showed at screen
            ShowStatus();
            second = time(NULL); /* Gets system time again */
         }
         else
            return(TRUE);
      }
      esckey = (bioskey(0) & 0xFF);
      if ( esckey == ESC ) {
         thinborder(2);   //nonactive Test Result window
         if ( AskUser(sAbortOrNot) == YES ) {
            fQuit = TRUE;
            return(FALSE);
         }
         else {
            thickborder(2);     //active Test Result window
	    break;
         }
      }
      else if ( esckey == SPACE ) {
	      while ( ScanKeybd() != C_KEY )
              break;
           }   

      second = time(NULL); /* Gets system time again */
   } /* end of FOR loop */
   return(TRUE);
}

int  Wait(int interval)    //interval : time in seconds
{
   register int i, k;

   k = interval*10;    /* delay is in 1/10 seconds */
   if (interval > 0) {
      for (i = 0; i < k; i++) {
         while (!(inp(0x3da) & 0x08));
         while ((inp(0x3da) & 0x08));
      }
   }
   return(TRUE);
} /* Wait */

void ShowDate(void)
{
   long ltime;
   char asctime[16];
   char *time1;

   time( &ltime );                      //Get time of a day
   time1 = ctime( &ltime );             //Convert day and time to string
   strncpy( asctime, time1, 10 );
   strcpy( &asctime[10], ", " );
   strncpy( &asctime[12], &time1[20], 4 );
   asctime[16] = '\0';
   gotoxy( 11, 24 );
   printf( asctime );
//   textattr( ( BROWN << 4 ) | LIGHTCYAN);
//   cprintf( asctime);
//   textattr( attribute);
}

void ShowTime(void)
{
   static lastsec = 0;
   struct time now;
   struct coor {
	   int x, y;
   } pos;

   pos.x = wherex();
   pos.y = wherey();
   gettime( &now );
   if ( lastsec != now.ti_sec ) {
      gotoxy( 68, 24 );
      if ( attribute != 0x07 )
	 textattr( ( LIGHTGRAY << 4 ) | RED );
      else
         textattr( 0x70 );
      cprintf( "%2d:%2d:%2d", now.ti_hour, now.ti_min, now.ti_sec );
      lastsec = now.ti_sec;
      gotoxy( pos.x, pos.y );
      textattr( attribute );
   }
}

void ShowStatus(void)
{
   gotoxy(77,21);
   status_reg_val = inportb(status_reg);
   cprintf("%2X",status_reg_val);
}



/****************************************************************************
* hor_menusel(x, y, xl, item, *msg[], key[], sel)
*
*   This rountine performs horizontal selection for "Yes" or "No".
*
* Entry:  (x, y) - screen position, x:col, y:row
*         xl     -
*         item   - item : no. of choice
*         *msg[] - item name
*	  key[]  - first character of item
* 	  sel    - start item no.
* Return: -1 : ESC-give up
*         0  : Yes-do it
*         1  : No-give up
****************************************************************************/
int  hor_menusel(int x, int y, int xl, int item,
                 char *msg[], char key[], int sel)
{
   union {
         int icode;
         char ch[2];
   } keyin;
   int i, start=0;
   int select = sel;

   _setcursortype( _NOCURSOR );
   for ( ; ; ) {

exitloop1:
      InvertText( x+(select*xl), y, msg[select], invattr );
      keyin.icode = get_keyin( 1, 1 );        //ASCII code
      InvertText( x+(select*xl), y, msg[select], attribute );
      if ( keyin.ch[0] != 0 ) {
	 if ( key != NULL ) {
	    for ( i = start ; i < xl ; i ++ )
		if ( tolower(keyin.ch[0]) == key[i] )
		   return ( i );
	 }
	 switch ( keyin.ch[0] ) {
	    case ESC : // 10/07 Tang updated
	    	       //select = -1;
		       // 10/07 Tang updated
	    	       select = 1;  //No
		       break;
	    case RET : InvertText( x+(select*xl), y, msg[select], invattr );
		       break;
	    default  : goto exitloop1;
	 }
	 _setcursortype( _NORMALCURSOR );
	 return ( select ) ;
      }
      else {
	 switch ( keyin.ch[1] ) {
	    case LEFT : if ( select > start )
			   select --;
			else
			   select = item - 1;
			break;
	    case RIGHT: if ( select < ( item - 1 ) )
			   select ++;
			else
			   select = start;
			break;
	    case HOME : select = start;
			break;
	    case END  : select = item - 1;
			break;
	 }
      } /* end of if-else */
   } /* end of FOR loop */
}


/***************************************************************************
* GetMenuSelect(xLeft, yTop, yRow, *sItemtext, Hotkey[], sel, *message)
*
*   This routine select an item within a specified window
*
* Entry:  ( xLeft, yTop ) - left top screen coord.
*	  yRow - no. of rows to select
*	  *sItemtext - string of item text
*	  Hotkey[] - shortcut key to select item
*	  sel - start row(usualy is 0) to select
*	  *message - explain message
**************************************************************************/
int  GetMenuSelect(int xLeft, int yTop, int yRow,
                   char *sItemtext[], char Hotkey[], int sel, char *message[])
{
   union {
         int icode;
         char ch[2];
   } keyin;
   int i , lsel, startitem;
   int select = sel;

   if ( yRow == nItemsMain ) startitem=0;   //MainMenu:start from 0th row
   else                      startitem=1;   //Customer:start from 2nd row
   lsel = sel;    //where to start(initial/current)
   if ( message != NULL ) {
      gotoxy( 3, 23 );
      textattr( msg_attr );
      cprintf( message[select] );
      textattr( attribute );
//      puts( message[select] );
   }
   InvertText( xLeft, yTop+select, *( sItemtext+select ) , invattr );
   _setcursortype( _NOCURSOR );

   /* waiting user move lightbar to select item */
   for ( ; ; ) {
exitloop:
      if ( lsel != select ) {
	 InvertText( xLeft, yTop+select, *( sItemtext+select ) , invattr );
	 InvertText( xLeft, yTop+lsel, *( sItemtext+lsel ) , attribute );
	 if ( message != NULL ) {
	    gotoxy( 3, 23 );
      	    textattr( msg_attr );
      	    cprintf( message[select] );
 	    textattr( attribute );
//	    puts( message[select] );
	 }
      }
      lsel = select;
      keyin.icode = get_keyin( 1, 1 );

      if ( keyin.ch[0] != 0 ) {
         /*  get a ASCII code, not extended code */
	 if ( Hotkey != NULL ) {
    	    /* for main menu selection, provide Hotkey to pick */
	    for ( i = 0; i < yRow; i ++ ) {
	       if ( tolower(keyin.ch[0]) == Hotkey[i] ) {
		  InvertText( xLeft, yTop+lsel, *( sItemtext+lsel ) , attribute );
		  if ( message != NULL ) {
		     gotoxy( 3, 23 );
      	    	     textattr( msg_attr );
      	    	     cprintf( message[select] );
 	    	     textattr( attribute );
//		     puts( message[select] );
		  }
		  InvertText( xLeft, yTop + i, *( sItemtext+i ) , invattr );
		  _setcursortype( _NORMALCURSOR );
		  return( i );
	       }
	    }
	 }  /* end of IF (Hotkey!=NULL) */

	 /* customer menu selction, no Hotkey select, general case */
	 switch ( keyin.ch[0] ) {
	    case ESC : InvertText( xLeft, yTop+lsel, *( sItemtext+lsel ) , attribute );
		       select = -1;
		       lsel = 0;
		       break;
            case g_KEY :
            case G_KEY :if ( yRow == nItemsUser ) {  //use only at Customer
                           InvertText( xLeft, yTop+lsel, *( sItemtext+lsel ) , attribute );
                           select = yRow;            //if Default, return
		           break;
                        }
	    case RET : /*InvertText( x, y + lsel , *( msg+lsel ), invattr ) ;*/
	    case SPACE :
		       break;
	    default  : goto exitloop;
	 }
	 _setcursortype( _NORMALCURSOR );
	 return( select );
      }  /* end of IF-keyin.ch[0]  */

      else {
         /* get a extended code, arrow up, down, left, right .... */
	 switch ( keyin.ch[1] ) {
	    case UP  :	//if ( select > 0 )
                        if ( select > startitem )
			   select --;
			else
			   select = yRow - 1;
			break;
	    case DOWN : if ( select < ( yRow - 1 ) )
			   select ++;
			else
			   //select = 0;
			   select = startitem;   //where to start
			break;
	    case PGUP :
	    case HOME : //select = 0;
		        select = startitem;   //where to start
			break;
	    case PGDN :
	    case END  : select = yRow - 1;
			break;
	 } /* end of switch */
      }
   } /* end FOR-loop */
} /* end of function GetMenuSelect() */

/***************************************************************************
* SetupWindow(xLeft, yTop, xRight, yBottom, buffer, msg, attr)
*
*   This routine create a text window located at left top (xLeft, yTop) and
* rirht down (xRight, lBottom), store text which located in this window into
* buffer for later restore to original state. Besides, it draw a double line
* border and text out a string(msg).
*
* Entry:  ( xLeft, yTop ) - left top screen coord.
*	  ( xRight, yBottom ) - right bottom screen coord.
*	  *buffer - for store the text
*	  msg[] - output text msg
*	  attr - attribute to output text
* Return: a rect. window and inside-window text
**************************************************************************/
void SetupWindow(int xLeft, int yTop, int xRight, int yBottom,
                 char *buffer, char msg[], int attr)
{
   int len;

   len = strlen( msg );
   textattr( attr );
   /* save specified window's text to buffer for recover later */
   gettext( xLeft, yTop, xRight, yBottom, buffer ); //grab onscreen text to memory
   /* create a specified window */
   window( xLeft, yTop, xRight, yBottom );
   clrscr();  //clear the current text window and locate cusor
   window( 1, 1, 80, 25 );  //relocate coordinate(for DrawBorder fun.)
   /* draw a double line border */
   DrawBorder( xLeft, yTop, xRight-xLeft+1, yBottom-yTop+1, 1, attr );
   xRight = ( xRight - len - xLeft + 1 ) >> 1;
   gotoxy( xLeft + xRight, yTop );
//   cputs( msg );	//output text in this window
   // 10/06 Tang added
   textattr(attribute);
   window( 1, 1, 80, 25 );
   // 10/06 Tang added
}


int AskUser(char *sWhat)
{
   char *buffer;
   int i;
   int tempattr=0x07, invdisp=0x07;
   char *sYNmsg[] = { " Yes ", " No " };

   if ( (buffer = (char *)malloc(420)) == NULL ) {
      MessageOut(xShow, "Not enough memory!");
      exit(1);
   }
   if ( attribute != 0x07 ) {
      invdisp = attribute;
      tempattr = val_attr;
   }
   gettext( 17, 11, 58, 15, buffer );
   if ( nTestType == 0 )   //Default
      SetupWindow( 17, 11, 58, 15, buffer, " Default  test ", tempattr );
   else                    //Customer
      SetupWindow( 17, 11, 58, 15, buffer, " Customer test ", tempattr );
   gotoxy( 22, 12 );
   puts( sWhat );
   gotoxy( 32, 14 );
   puts( "Yes       No" );
   i = hor_menusel( 31, 14, 10, 2, sYNmsg, "yn", 0 );
//  attribute = invdisp;
   puttext( 17, 11, 58, 15, buffer );
   free(buffer);
   // Tang added
   textattr(attribute);
   return( i );
}


void ShowResultMsg(char *sWhat)
{
   char *buffer;
   int  i;
   int  tempattr=0x07, invdisp=0x07;

   if ( (buffer = (char *)malloc(176)) == NULL ) {
      MessageOut(xShow, "Not enough memory!");
      exit(1);
   }
   if ( attribute != 0x07 ) {
      invdisp = attribute;
      tempattr = val_attr;
//      attribute = (BLUE << 4 ) | YELLOW;
   }
   SetupWindow( 17, 21, 65, 24, buffer, " Junior test ", tempattr );
   gotoxy( 22, 22 );
   puts( sWhat );
   gotoxy( 28, 23 );
   puts( "Press any key to continue." );
   while ( !kbhit() ) //keystrike is not available
      ShowTime();
   getch();    //read out the key, necessary!
//   attribute = invdisp;
   puttext( 17, 21, 65, 24, buffer );
   free(buffer);
   // Tang added
   textattr(attribute);
}

void scrollup(int ux, int uy, int lx, int ly)
{
   union REGS  reg;

   reg.x.ax = 0x601;
   reg.h.bh = (char)attribute;
   reg.h.ch = uy - 1;
   reg.h.cl = ux - 1;
   reg.h.dh = ly - 1;
   reg.h.dl = lx - 1;
   int86( 0x10, &reg, &reg );
}

void scrolldown(int ux, int uy, int lx, int ly)
{
   union REGS  reg;

   reg.x.ax = 0x701;
   reg.h.bh = (char)attribute;
   reg.h.ch = uy - 1;
   reg.h.cl = ux - 1;
   reg.h.dh = ly - 1;
   reg.h.dl = lx - 1;
   int86( 0x10, &reg, &reg );
}

/****************************************************************************
* get_dec_int(x, y, len, def)
*
*   Goto (x, y) and get decimal interger input from keyboard.
*
* Entry: (x, y) - coordinate to get input.
*        len - no. of digit(length of interger),
*        def - default int value
****************************************************************************/
get_dec_int(int x, int y, int len, int def)
{
   union {
	int i;
	char ch[2];
   } keyin;
   char buffer[20];
   int size = def, i, j;

   itoa( def, buffer, len*2 );
   for ( i = 0; i < len; ) {
      keyin.i = get_keyin( x+i, y );
      switch ( keyin.ch[0] ) {
	 case '0' :
	 case '1' :
	 case '2' :
	 case '3' :
	 case '4' :
	 case '5' :
	 case '6' :
	 case '7' :
	 case '8' :
	 case '9' : if ( i == 0 ) {
		       for ( j = 0; j < len; j ++ )
			  putch ( ' ' );
		       gotoxy( x, y );
		    }
		    buffer[i] = keyin.ch[0];
		    putch( keyin.ch[0] );
		    i ++ ;
		    break;
	 case 8   : if ( i > 0 ) {
		       putch( keyin.ch[0] );
		       putch( ' ' );
		       putch( keyin.ch[0] );
		       i -- ;
		    }
		    break ;
	 case RET : if ( i != 0 )
		       buffer[i] = 0;
		       size = atoi( buffer );
		       if ( i != 0 )
			  return( size );
	 case ESC : return( def );
      }
   }
   buffer[i] = 0;
   size = atoi( buffer );
   return( size );
}

/****************************************************************************
* get_hex_int(x, y, len, def)
*
*   Goto (x, y) and get hex interger input from keyboard.
*
* Entry: (x, y) - coordinate to get input.
*        len - no. of digit(length of interger),
*        def - default int value
****************************************************************************/
int get_hex_int(int x, int y, int len, int def)
{
   union {		//Use for input key(int 16h style)
      int icode;        //integer for ASCII code
      char ch[2];       //high byte & low byte of integer
   } keyin;
   char buffer[10];
   int size = def, i, j;

   itoa( def, buffer, len*2 );   //convert to ascii string
   for ( i=0; i<len; ) {
      keyin.icode = get_keyin(x+i, 18 );
      switch ( keyin.ch[0] ) {
	 case '0' :
	 case '1' :
	 case '2' :
	 case '3' :
	 case '4' :
	 case '5' :
	 case '6' :
	 case '7' :
	 case '8' :
	 case '9' :
	 case 'A' :
	 case 'a' :
	 case 'B' :
	 case 'b' :
	 case 'C' :
	 case 'c' :
	 case 'D' :
	 case 'd' :
	 case 'E' :
	 case 'e' :
	 case 'F' :
	 case 'f' : if ( i == 0 ) {                //clear original chars
		       for ( j=0; j<len; j ++ )
			  putch( ' ' );
		       gotoxy( x, y );
		    }
		    buffer[i] = keyin.ch[0];
		    putch( keyin.ch[0] );         //show keyin char
		    i ++ ;
		    break;
	 case 8   : if ( i > 0 ) {
		       putch( keyin.ch[0] );
		       putch( ' ' );
		       putch( keyin.ch[0] );
		       i -- ;
		    }
		    break;
	 case RET : if ( i != 0 )
		       buffer[i] = 0;
//		    size = atoi( buffer );
                    size = hex_string_to_int( buffer );
		    if ( i != 0 )
		       return( size );
	 case ESC : return( def );
      }
   }
   buffer[i] = 0;
//   size = atoi( buffer );
   size = hex_string_to_int( buffer );
   return( size );
}

/****************************************************************************
* get_string(x, y, len, buffer[], def[], cover)
*
*   Goto coord. (x, y) and get string from console.
*
* Entry: (x, y) - screen coord. which location accepted to keyin string,
*        len - length of string,
*        buffer[] - storage of string,
*        def[] -
*        cover -
****************************************************************************/
int get_string(int x, int y, int len, char buffer[], char def[], int cover)
{
   int i, j;
   union {
      int i;
            char ch[2];
   } keyin;

   for ( i = 0; i < len; i ++ ) {
      gotoxy( x+1, y );
      keyin.i = get_keyin( x+i, y );
      if ( isalnum(keyin.ch[0]) || keyin.ch[0] == '.' )  {
	 if ( i == 0 ) {
	    for ( j = 0; j < len; j ++ )
	       putch( ' ' );
	    gotoxy( x, y );
	 }
	 putch( (cover) ? '*' : keyin.ch[0] );
	 buffer[i] = keyin.ch[0];
      }
      else
	 switch ( keyin.ch[0] ) {
	    case 0x08 : if ( i > 0 ) {
			   i -- ;
			   buffer[i] = 0;
			   putch( keyin.ch[0] );
			   putch( ' ' );
			   if ( i == 0 ) {
			      putch( keyin.ch[0] );
			      puts( def );
			      gotoxy( x, y );
                              			   }
			}
	    default   : i -- ;
			break;
	    case RET  : buffer[i] = 0;
			return( i );
	    case ESC  : return( 0 );
	 } /* end of switch */
   } /* end of for */
   buffer[i] = 0;
   return( i );
}

/***************************************************************************
* ScanKeybd() - read the key board without echo, return extended key code  *
***************************************************************************/
int ScanKeybd(void)
{
   int ext_key_code;
   int a,b;

    b = 0;
    a = getch();
    if (a == 0) {
	b = 0x100;
	a = getch();
    }
    ext_key_code = b+(a & 0xff);
    return(ext_key_code);
}

/***************************************************************************
* ControlKey() - Checking if ever press the control key.		   *
***************************************************************************/
void ControlKey(void)
{
   if ( kbhit() )
      switch ( ScanKeybd() ) {
	 case ESC:		/* Quit the program. */
	 case Q_KEY:
                  fQuit = 1;
		  break;
	 case P_KEY:		/* Pause the program. */
		  while ( ScanKeybd() != C_KEY )
		  break;
	 default: return;
      }
   return;
}

/****************************************************************************
* GetVideoMode()
*   Get the current mode of screen by BIOS INT 10h, AH=0Fh.
*
* Entry: None
* Return: mode_no
****************************************************************************/
int  GetVideoMode(void)
{
   _AH = 0x0f ;
   geninterrupt( 0x10 ) ;
   return( _AX & 0xff ) ;
}

//1/21 Tang added
void SetVideoMode(BYTE mode_no)
{
   _AH = 0x00 ;
   _AL = mode_no;
   geninterrupt( 0x10 ) ;
   return( _AX & 0xff ) ;
}




